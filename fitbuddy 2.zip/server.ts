import express from 'express';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import nodemailer from 'nodemailer';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// --- Database Setup ---
const db = new Database('auth.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS otps (
    email TEXT PRIMARY KEY,
    otp TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    attempts INTEGER DEFAULT 0
  )
`);

// --- Email Setup ---
// Default to a console logger if no SMTP config is present, but try to use env vars
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.ethereal.email',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_PORT === '465', // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER || 'ethereal_user',
    pass: process.env.SMTP_PASS || 'ethereal_pass',
  },
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API Routes ---

  // Send OTP
  app.post('/api/auth/send-otp', async (req, res) => {
    try {
      const { email } = req.body;
      if (!email || !email.includes('@')) {
        return res.status(400).json({ error: 'Invalid email address' });
      }

      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = Date.now() + 5 * 60 * 1000; // 5 minutes from now

      // Store in DB (upsert)
      const stmt = db.prepare(`
        INSERT INTO otps (email, otp, expires_at, attempts)
        VALUES (?, ?, ?, 0)
        ON CONFLICT(email) DO UPDATE SET
        otp = excluded.otp,
        expires_at = excluded.expires_at,
        attempts = 0
      `);
      stmt.run(email, otp, expiresAt);

      // Send Email
      // Note: In a real production app without env vars, this might fail or log to console.
      // We'll try to send and log the OTP to console for dev convenience as well.
      console.log(`[DEV] OTP for ${email}: ${otp}`);

      if (process.env.SMTP_HOST) {
        // Use the authenticated user as the 'from' address to avoid spam filters
        // when sending via personal Gmail/SMTP.
        const sender = process.env.SMTP_USER || '"FitAI Coach" <no-reply@fitai.com>';
        
        await transporter.sendMail({
          from: sender,
          to: email,
          subject: 'Your FitAI Verification Code',
          text: `Your verification code is: ${otp}. It expires in 5 minutes.`,
          html: `<p>Your verification code is: <b>${otp}</b></p><p>It expires in 5 minutes.</p>`,
        });
      } else {
        console.log('No SMTP_HOST configured. OTP logged to console only.');
      }

      res.json({ success: true, message: 'OTP sent successfully' });
    } catch (error) {
      console.error('Error sending OTP:', error);
      res.status(500).json({ error: 'Failed to send OTP' });
    }
  });

  // Verify OTP
  app.post('/api/auth/verify-otp', (req, res) => {
    try {
      const { email, otp } = req.body;
      
      if (!email || !otp) {
        return res.status(400).json({ error: 'Email and OTP are required' });
      }

      const stmt = db.prepare('SELECT * FROM otps WHERE email = ?');
      const record = stmt.get(email) as { otp: string, expires_at: number, attempts: number } | undefined;

      if (!record) {
        return res.status(400).json({ error: 'No OTP request found for this email' });
      }

      // Check attempts
      if (record.attempts >= 3) {
        return res.status(400).json({ error: 'Too many failed attempts. Please request a new OTP.' });
      }

      // Check expiry
      if (Date.now() > record.expires_at) {
        return res.status(400).json({ error: 'OTP has expired' });
      }

      // Check OTP match
      if (record.otp !== otp) {
        // Increment attempts
        db.prepare('UPDATE otps SET attempts = attempts + 1 WHERE email = ?').run(email);
        return res.status(400).json({ error: 'Invalid OTP' });
      }

      // Success - Delete OTP record to prevent reuse
      db.prepare('DELETE FROM otps WHERE email = ?').run(email);

      res.json({ success: true, message: 'Login successful' });
    } catch (error) {
      console.error('Error verifying OTP:', error);
      res.status(500).json({ error: 'Verification failed' });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static file serving would go here
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
