# FitBuddy - Home-Based Fitness & Diet Comprehensive List

Yeh list specifically un logon ke liye design ki gayi hai jo **gym nahi ja sakte** aur ghar par reh kar hi **bodyweight ya ghar ki cheezon (water bottles, chairs, towels)** ka istemal karke fit rehna, weight loss karna, ya muscular body banana chahte hain. Isme Indian aur general home-based meals bhi shamil hain.

---

## 🏋️‍♂️ Home Workout Exercises (No Gym Equipment)

### 1. Muscle Building (Strength & Hypertrophy)
**Chest & Triceps:**
- Standard Push-ups
- Wide Grip Push-ups
- Diamond Push-ups (Triceps focus)
- Incline Push-ups (Hands on a chair/bed)
- Decline Push-ups (Feet on a chair/bed)
- Pike Push-ups (Shoulders focus)
- Chair Dips (Triceps focus using a sturdy chair)
- Water Bottle Floor Press (Lying on floor, pressing heavy water bottles)

**Back & Biceps:**
- Towel Rows (Pulling a towel wrapped around a sturdy pole/door handle)
- Table Inverted Rows (Pulling yourself up under a sturdy dining table)
- Water Bottle Bicep Curls (Using 1L or 2L filled water bottles)
- Water Bottle Bent-Over Rows
- Superman Holds (Lower back focus)
- Doorway Pull-ups (If a pull-up bar is available, otherwise stick to rows)

**Legs & Glutes:**
- Bodyweight Squats
- Jump Squats
- Bulgarian Split Squats (One foot resting on a chair/sofa)
- Forward & Reverse Lunges
- Walking Lunges
- Glute Bridges (Lying on back, lifting hips)
- Single-Leg Glute Bridges
- Calf Raises (Standing on the edge of a stair)
- Wall Sits (Isometric hold against a wall)

**Core & Abs:**
- Forearm Plank
- High Plank
- Side Plank
- Bicycle Crunches
- Leg Raises (Lying flat, lifting straight legs)
- Russian Twists (Holding a water bottle for resistance)
- Mountain Climbers
- V-Ups / Toe Touches

### 2. Cardio & Fat Loss (High-Intensity)
- Burpees
- Jumping Jacks
- High Knees
- Spot Jogging (Running in place)
- Jump Rope (Skipping - actual or shadow skipping)
- Skaters (Side-to-side jumps)
- Butt Kicks
- Squat Thrusts

### 3. Flexibility, Mobility & Yoga (Recovery)
- Surya Namaskar (Sun Salutation)
- Downward Facing Dog
- Cobra Pose (Bhujangasana)
- Child's Pose (Balasana)
- Cat-Cow Stretch
- Butterfly Stretch
- Neck & Shoulder Rolls
- Standing Toe Touches

---

## 🥗 Home-Based Diet Plans (Indian & General)

Yeh meals ghar par aasani se banaye ja sakte hain aur inme high protein, complex carbs, aur healthy fats ka balance hai.

### 1. Muscle Building (High Protein, Caloric Surplus/Maintenance)
**Breakfast:**
- Paneer Bhurji with 2 Whole Wheat Rotis
- 3-4 Egg Omelette with Spinach and 2 slices of Brown Bread
- Oats Chilla (Pancakes) with Peanut Butter
- Soya Chunks Poha

**Lunch:**
- Soya Chunks Curry with Brown Rice / Roti
- Chicken Curry (Home-style) with Rice and Cucumber Salad
- Rajma (Kidney Beans) or Chole (Chickpeas) with Rice
- Mixed Dal (Lentils) with Quinoa or Roti and Curd

**Dinner:**
- Grilled/Tawa Paneer Tikka with Mint Chutney and Salad
- Egg Curry (2 whole eggs, 2 egg whites) with Roti
- Moong Dal Khichdi with a side of Curd
- Tawa Chicken Breast with Sautéed Veggies (Broccoli, Carrots)

**Snacks:**
- Roasted Makhana (Fox nuts)
- Handful of Mixed Nuts (Almonds, Walnuts, Peanuts)
- Banana Smoothie with Milk and Peanut Butter
- Boiled Kala Chana (Black Chickpeas) Chaat

### 2. Weight Loss / Fat Loss (High Protein, Caloric Deficit)
**Breakfast:**
- Moong Dal Chilla (Green gram pancakes) with Mint Chutney
- 2 Boiled Egg Whites and 1 Whole Egg with Black Coffee
- Masala Oats with lots of veggies (Carrots, Peas, Beans)
- Papaya and Apple Bowl with Chia Seeds

**Lunch:**
- 1 Roti with a large bowl of Dal (Lentils) and Sabzi (Bhindi, Ghiya, or Tinda)
- Large bowl of Sprout Salad (Moong, Chana, Onion, Tomato, Lemon)
- Soya Bean Salad with Cucumber and Tomatoes
- Clear Chicken Soup with Veggies

**Dinner:**
- Grilled Fish or Tawa Paneer with a large bowl of Green Salad
- Bottle Gourd (Lauki) Sabzi with 1 Multigrain Roti
- Dal Soup (Thin consistency)
- Sautéed Tofu with Bell Peppers

**Snacks:**
- Green Tea with 2-3 Almonds
- Roasted Chana (Chickpeas)
- Cucumber and Carrot Sticks with Hummus/Curd dip
- Buttermilk (Chaas)

### 3. Weight Gain (Caloric Surplus, Nutrient Dense)
**Breakfast:**
- 2 Bananas, 1 Glass Full-Cream Milk, 2 tbsp Peanut Butter (Smoothie)
- Aloo Paratha (with less oil) and a bowl of Curd
- 4 Scrambled Eggs with Cheese and 3 slices of Bread

**Lunch:**
- Large portion of Rice with thick Dal Makhani or Paneer Butter Masala (Home-style)
- Chicken Biryani (Home-cooked with less oil) and Raita
- Sweet Potato Mash with Soya Chunks Curry

**Dinner:**
- Mutton Curry or Heavy Chicken Curry with 3 Rotis
- Paneer Paratha with Butter
- Large bowl of Pasta with Mixed Veggies and Cheese

**Snacks:**
- Dates (Khajoor) and Milk
- Peanut Chikki
- Boiled Potatoes with Chaat Masala

---

## 🚀 Future Predictions (To Add Later)

Jaise-jaise users progress karenge, aap in advanced exercises aur meals ko app mein introduce kar sakte hain:

### Advanced Home Exercises (Future)
- **Handstand Push-ups (Against a wall):** For extreme shoulder strength.
- **Pistol Squats (Assisted with a chair first):** For advanced leg strength and balance.
- **Planche Progressions:** For elite core and shoulder strength.
- **L-Sits (On two sturdy chairs):** For intense core activation.
- **Plyometric Push-ups (Clapping push-ups):** For explosive chest power.
- **Resistance Band Workouts:** (Users can buy cheap bands for bicep curls, lateral raises, and face pulls).

### Advanced/Trendy Meals (Future)
- **Protein Smoothies with Whey/Plant Protein Powder:** Once users are ready to invest in supplements.
- **Overnight Oats with Greek Yogurt & Berries:** A trendy, high-protein breakfast.
- **Zucchini Noodles (Zoodles) with Pesto:** For extreme low-carb/keto days.
- **Cauliflower Rice Biryani:** A low-calorie alternative to regular rice.
- **Air-Fried Chicken/Paneer:** Healthier, oil-free cooking methods.
- **Matcha Green Tea & Kombucha:** For gut health and metabolism.
- **Ashwagandha Milk (Moon Milk):** For stress relief and better sleep recovery.
