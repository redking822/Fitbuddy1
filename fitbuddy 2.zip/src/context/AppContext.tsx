import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth, db } from '@/lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, updateDoc, setDoc, onSnapshot, deleteDoc, getDoc } from 'firebase/firestore';
import { get, set, del } from 'idb-keyval';
import { calculateDailyTarget, calculateProteinTarget } from '@/screens/onboarding/services/calorieService';
import { clearUserHistory } from '@/screens/onboarding/services/historyService';
import { handleFirestoreError, OperationType } from '@/lib/firestoreUtils';

// --- Types ---

export type UserGender = 'Male' | 'Female' | 'Other';
export type DietType = 'Veg' | 'Non-Veg' | 'Mixed';
export type FitnessGoal = 'Weight Loss' | 'Muscle Building' | 'Weight Gain';
export type ActivityLevel = 'Sedentary' | 'College Student' | 'School Student' | 'Office Worker';
export type FitnessLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export interface Schedule {
  departureTime: string;
  returnTime: string;
  holidays: string[];
}

export interface DailyStats {
  dayId: string;
  calories: number;
  protein: number;
  water: number;
  workouts: number;
  date: string;
  calorieTarget: number;
  proteinTarget: number;
  completedExercises: string[];
  isDayComplete: boolean;
}

export interface Meal {
  name: string;
  ingredients: string[];
  protein: number;
  calories: number;
  energy: string;
  portionSize: string;
  quantity: string;
  preparation: string;
  tutorialUrl?: string;
}

export interface GroceryItem {
  name: string;
  category: 'Vegetables' | 'Fruits' | 'Grains' | 'Protein Sources' | 'Dairy' | 'Other';
}

export interface DailyDiet {
  day: string;
  breakfast: Meal | null;
  lunch: Meal | null;
  snack: Meal | null;
  dinner: Meal | null;
  dailyNutritionSummary: {
    totalCalories: number;
    totalProtein: number;
  };
}

export interface DietPlan {
  days: DailyDiet[];
  groceryList: GroceryItem[];
}

export interface WorkoutExercise {
  name: string;
  sets: number;
  reps: string;
  restTime: string;
  instruction: string;
  tutorialUrl: string;
}

export interface DailyWorkout {
  day: string;
  title: string;
  duration: string;
  isRestDay: boolean;
  warmup: WorkoutExercise[];
  mainExercises: WorkoutExercise[];
  cooldown: WorkoutExercise[];
  motivationalMessage: string;
}

export interface WorkoutPlan {
  days: DailyWorkout[];
}

export interface CompletedWorkout {
  dayId: string;
  date: string;
  title: string;
  duration: string;
  status: 'Completed' | 'Partial';
}

export interface CompletedMeal {
  dayId: string;
  date: string;
  mealName: string;
  calories: number;
  protein: number;
  type: string;
}

export interface WeightEntry {
  date: string;
  weight: number;
}

export interface UserProfile {
  name: string;
  email: string;
  age: number;
  gender: UserGender;
  weight: number;
  height: number;
  diet: DietType;
  goal: FitnessGoal;
  activityLevel: ActivityLevel;
  fitnessLevel: FitnessLevel;
  isOnboarded: boolean;
  termsAccepted: boolean;
  profileImage?: string;
  schedule?: Schedule;
  dailyStats: DailyStats;
  dietPlan?: DietPlan | null;
  workoutPlan?: WorkoutPlan | null;
  completedWorkouts: (string | CompletedWorkout)[]; 
  completedMeals?: CompletedMeal[];
  weightHistory?: WeightEntry[];
}

interface AppContextType {
  user: UserProfile | null;
  setUser: (user: UserProfile | null) => void;
  updateUser: (updates: Partial<UserProfile>) => void;
  updateDailyStats: (updates: Partial<DailyStats>) => void;
  logout: () => Promise<void>;
  isLoading: boolean;
  error: string | null;
  isOffline: boolean;
  termsAccepted: boolean;
  setTermsAccepted: (accepted: boolean) => void;
}

// --- Context ---

const AppContext = createContext<AppContextType | undefined>(undefined);

// --- Provider ---

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [termsAccepted, setTermsAcceptedState] = useState<boolean>(() => {
    return localStorage.getItem('fitbuddy_terms_accepted') === 'true';
  });

  const setTermsAccepted = async (accepted: boolean) => {
    setTermsAcceptedState(accepted);
    localStorage.setItem('fitbuddy_terms_accepted', accepted ? 'true' : 'false');
    
    // Sync to Firestore if logged in, regardless of local 'user' state
    if (auth.currentUser) {
      const userPath = `users/${auth.currentUser.uid}`;
      try {
        const userDocRef = doc(db, "users", auth.currentUser.uid);
        await updateDoc(userDocRef, { termsAccepted: accepted });
        
        // Also update local user state if it exists
        if (user) {
          setUser({ ...user, termsAccepted: accepted });
        }
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, userPath);
      }
    }
  };

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    // Load from IDB initially for instant feel
    get('fitbuddy_user').then((stored) => {
      if (stored) {
        setUser(stored);
        setIsLoading(false); // Set loading to false if we have cached data
      }
    }).catch(e => console.error("Failed to load from IDB", e));

    let unsubscribeSnapshot: (() => void) | null = null;

    // Listen for Firebase auth state changes
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      // Clean up previous snapshot listener if it exists
      if (unsubscribeSnapshot) {
        unsubscribeSnapshot();
        unsubscribeSnapshot = null;
      }

      if (firebaseUser) {
        setIsLoading(true);
        setError(null);
        // User is signed in
        const userDocRef = doc(db, "users", firebaseUser.uid);

        // Timeout fallback to prevent infinite loading
        const loadingTimeout = setTimeout(() => {
          setIsLoading(false);
          setError("Connection to database timed out. Please check your internet connection or try again later.");
        }, 10000); // 10 seconds max wait

        try {
          // First, check if the document exists using getDoc to avoid cache-related overwrites
          // Add a timeout to prevent hanging if Firestore is blocked or offline
          const getDocPromise = getDoc(userDocRef);
          const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error("getDoc timeout")), 5000)
          );
          
          const initialSnap = await Promise.race([getDocPromise, timeoutPromise]) as any;
          
          if (initialSnap && !initialSnap.exists()) {
            // Create new user document if it doesn't exist on the server
            const today = new Date().toISOString().split('T')[0];
            const newUserData: UserProfile = {
              email: firebaseUser.email || '',
              name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
              age: 25,
              gender: 'Other',
              weight: 70,
              height: 170,
              diet: 'Mixed',
              goal: 'Weight Loss',
              activityLevel: 'Sedentary',
              fitnessLevel: 'Beginner',
              isOnboarded: false,
              termsAccepted: false,
              completedWorkouts: [],
              completedMeals: [],
              weightHistory: [],
              dailyStats: { 
                dayId: Date.now().toString(),
                calories: 0, 
                protein: 0, 
                water: 0, 
                workouts: 0, 
                date: today, 
                calorieTarget: 2000,
                proteinTarget: calculateProteinTarget({ weight: 70, goal: 'Weight Loss' } as any),
                completedExercises: [],
                isDayComplete: false
              }
            };
            
            setUser(newUserData);
            set('fitbuddy_user', newUserData);
            setDoc(userDocRef, newUserData).catch(e => console.error("setDoc error:", e));
          }
        } catch (e) {
          console.error("Error checking/creating user doc:", e);
        }

        // Use onSnapshot for real-time sync and better offline handling
        unsubscribeSnapshot = onSnapshot(userDocRef, 
          async (docSnap) => {
            clearTimeout(loadingTimeout);
            if (docSnap.exists()) {
              const userData = docSnap.data() as UserProfile;
              const today = new Date().toISOString().split('T')[0];
              
              // Auto-fix isOnboarded for older accounts that have a plan but no flag
              if (userData.isOnboarded === undefined && (userData.dietPlan || userData.workoutPlan || userData.goal)) {
                userData.isOnboarded = true;
              }
              
              // Ensure daily stats are for today
              if (!userData.dailyStats || userData.dailyStats.date !== today) {
                const updatedData: UserProfile = {
                  ...userData,
                  termsAccepted: userData.termsAccepted || termsAccepted, // Sync from local if needed
                  completedWorkouts: userData.completedWorkouts || [],
                  completedMeals: [], // Hard reset for daily refresh
                  dailyStats: {
                    dayId: Date.now().toString(),
                    calories: 0,
                    protein: 0,
                    water: 0,
                    workouts: 0,
                    date: today,
                    calorieTarget: calculateDailyTarget(userData),
                    proteinTarget: calculateProteinTarget(userData),
                    completedExercises: [],
                    isDayComplete: false
                  }
                };
                setUser(updatedData);
                if (updatedData.termsAccepted && !termsAccepted) {
                  setTermsAcceptedState(true);
                  localStorage.setItem('fitbuddy_terms_accepted', 'true');
                }
                try {
                  setDoc(userDocRef, updatedData); // Update Firestore for daily refresh
                  set('fitbuddy_user', updatedData);
                } catch (e) {
                  console.error("Failed to update daily stats:", e);
                }
              } else {
                // Sync termsAccepted from local to Firestore if needed
                if (termsAccepted && !userData.termsAccepted) {
                  const updatedData = { ...userData, termsAccepted: true };
                  setUser(updatedData);
                  updateDoc(userDocRef, { termsAccepted: true });
                } else {
                  setUser(userData);
                }

                // Sync termsAccepted state from user profile to local if needed
                if (userData.termsAccepted && !termsAccepted) {
                  setTermsAcceptedState(true);
                  localStorage.setItem('fitbuddy_terms_accepted', 'true');
                }
                try {
                  set('fitbuddy_user', userData);
                } catch (e) {
                  console.error("Failed to save to IDB:", e);
                }
              }
            }
            setIsLoading(false);
          },
          (error) => {
            clearTimeout(loadingTimeout);
            console.warn("Firestore snapshot error (expected if offline):", error);
            setError("Failed to sync with database. You may be offline.");
            setIsLoading(false);
          }
        );
      } else {
        // User is signed out
        setUser(null);
        del('fitbuddy_user');
        localStorage.removeItem('fitai_user'); // cleanup old key if exists
        localStorage.removeItem('fitbuddy_user'); // cleanup old key if exists
        setIsLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

  // Update calorie and protein target when profile changes
  useEffect(() => {
    if (user && user.isOnboarded) {
      const calorieTarget = calculateDailyTarget(user);
      const proteinTarget = calculateProteinTarget(user);
      
      if (calorieTarget !== user.dailyStats.calorieTarget || proteinTarget !== user.dailyStats.proteinTarget) {
        updateUser({
          dailyStats: {
            ...user.dailyStats,
            calorieTarget,
            proteinTarget
          }
        });
      }
    }
  }, [user?.weight, user?.height, user?.age, user?.gender, user?.goal, user?.isOnboarded]);

  const updateUser = async (updates: Partial<UserProfile>) => {
    // Update local state using functional update to ensure we have the latest state
    setUser(prev => {
      const newUser = prev ? { ...prev, ...updates } : (updates as UserProfile);
      try {
        set('fitbuddy_user', newUser);
      } catch (e) {
        console.error("Failed to save to IDB", e);
      }
      return newUser;
    });

    // Sync to Firestore if logged in
    if (auth.currentUser) {
      const userPath = `users/${auth.currentUser.uid}`;
      try {
        const userDocRef = doc(db, "users", auth.currentUser.uid);
        await updateDoc(userDocRef, updates as any);
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, userPath);
      }
    }
  };

  const updateDailyStats = async (updates: Partial<DailyStats>) => {
    if (!user) return;
    const newDailyStats = { ...user.dailyStats, ...updates };
    await updateUser({ dailyStats: newDailyStats });
  };

  const logout = async () => {
    try {
      await signOut(auth);
      del('fitbuddy_user');
      localStorage.removeItem('fitbuddy_user');
      localStorage.removeItem('fitbuddy_nav_hint');
      setUser(null);
    } catch (e) {
      console.error("Logout failed", e);
    }
  };

  return (
    <AppContext.Provider value={{ 
      user, 
      setUser, 
      updateUser, 
      updateDailyStats, 
      logout, 
      isLoading, 
      error,
      isOffline,
      termsAccepted,
      setTermsAccepted
    }}>
      {children}
    </AppContext.Provider>
  );
}

// --- Hook ---

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
