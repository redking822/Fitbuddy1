import React, { useState, useEffect, ReactNode, Suspense, lazy } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AppProvider, useApp } from '@/context/AppContext';
import SplashScreen from '@/screens/SplashScreen';
import LoginScreen from '@/screens/LoginScreen';
import SignupScreen from '@/screens/SignupScreen';
import TermsScreen from '@/screens/TermsScreen';

const NameScreen = lazy(() => import('@/screens/onboarding/NameScreen'));
const PersonalDetailsScreen = lazy(() => import('@/screens/onboarding/PersonalDetailsScreen'));
const DietHabitsScreen = lazy(() => import('@/screens/onboarding/DietHabitsScreen'));
const GoalScreen = lazy(() => import('@/screens/onboarding/GoalScreen'));
const ActivityLevelScreen = lazy(() => import('@/screens/onboarding/ActivityLevelScreen'));
const FitnessLevelScreen = lazy(() => import('@/screens/onboarding/FitnessLevelScreen'));

const DashboardScreen = lazy(() => import('@/screens/main/DashboardScreen'));
const DietScreen = lazy(() => import('@/screens/main/DietScreen'));
const DietHistoryScreen = lazy(() => import('@/screens/main/DietHistoryScreen'));
const WorkoutScreen = lazy(() => import('@/screens/main/WorkoutScreen'));
const ProgressScreen = lazy(() => import('@/screens/main/ProgressScreen'));
const ProfileScreen = lazy(() => import('@/screens/main/ProfileScreen'));
const WorkoutHistoryScreen = lazy(() => import('@/screens/main/WorkoutHistoryScreen'));
const SettingsScreen = lazy(() => import('@/screens/main/SettingsScreen'));

import { Loader2, AlertCircle } from 'lucide-react';
import OfflineScreen from '@/components/OfflineScreen';

class ErrorBoundary extends React.Component<{children: ReactNode}, {hasError: boolean, error: Error | null}> {
  constructor(props: {children: ReactNode}) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="h-screen w-full flex flex-col items-center justify-center bg-background p-6 text-center">
          <div className="bg-red-500/10 p-4 rounded-full mb-4">
            <AlertCircle className="h-8 w-8 text-red-500" />
          </div>
          <h2 className="text-xl font-bold mb-2">Something went wrong</h2>
          <p className="text-text-muted mb-6 text-sm max-w-xs">{this.state.error?.message || "Failed to load application component."}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-6 py-2 bg-primary text-white rounded-full font-medium"
          >
            Reload App
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, isLoading, error, termsAccepted: localAccepted, logout } = useApp();
  const location = useLocation();

  if (error) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-background p-6 text-center">
        <div className="bg-red-500/10 p-4 rounded-full mb-4">
          <AlertCircle className="h-8 w-8 text-red-500" />
        </div>
        <h2 className="text-xl font-bold mb-2">Connection Error</h2>
        <p className="text-text-muted mb-6">{error}</p>
        <div className="flex flex-col gap-3 w-full max-w-xs">
          <button 
            onClick={() => window.location.reload()} 
            className="w-full py-3 bg-primary text-white rounded-full font-medium"
          >
            Retry
          </button>
          <button 
            onClick={() => logout()} 
            className="w-full py-3 bg-surface-light text-white rounded-full font-medium"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const isOnboardingRoute = location.pathname.startsWith('/onboarding');
  const isTermsRoute = location.pathname === '/terms';

  // Redirect to terms if not accepted locally AND not in profile
  const isTermsAccepted = localAccepted || user.termsAccepted;
  if (!isTermsAccepted && !isTermsRoute) {
    return <Navigate to="/terms" replace />;
  }

  // Redirect away from terms if already accepted
  if (isTermsAccepted && isTermsRoute) {
    if (user.isOnboarded) return <Navigate to="/home" replace />;
    return <Navigate to="/onboarding/name" replace />;
  }

  // Redirect to onboarding if not onboarded, unless already on an onboarding route or terms
  if (!user.isOnboarded && !isOnboardingRoute && !isTermsRoute && isTermsAccepted) {
    return <Navigate to="/onboarding/name" replace />;
  }

  // Redirect to home if onboarded but trying to access onboarding routes
  if (user.isOnboarded && isOnboardingRoute) {
    return <Navigate to="/home" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  const { termsAccepted, isLoading, error, logout } = useApp();
  const location = useLocation();

  if (error) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-background p-6 text-center">
        <div className="bg-red-500/10 p-4 rounded-full mb-4">
          <AlertCircle className="h-8 w-8 text-red-500" />
        </div>
        <h2 className="text-xl font-bold mb-2">Connection Error</h2>
        <p className="text-text-muted mb-6">{error}</p>
        <div className="flex flex-col gap-3 w-full max-w-xs">
          <button 
            onClick={() => window.location.reload()} 
            className="w-full py-3 bg-primary text-white rounded-full font-medium"
          >
            Retry
          </button>
          <button 
            onClick={() => logout()} 
            className="w-full py-3 bg-surface-light text-white rounded-full font-medium"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 text-primary animate-spin" />
      </div>
    );
  }

  const isTermsRoute = location.pathname === '/terms';
  const isSplashRoute = location.pathname === '/';

  // Strict Legal Gate: Redirect to terms if not accepted, unless on splash or terms
  if (!termsAccepted && !isTermsRoute && !isSplashRoute) {
    return <Navigate to="/terms" replace />;
  }

  return (
    <ErrorBoundary>
      <Suspense fallback={
        <div className="h-screen w-full flex items-center justify-center bg-background">
          <Loader2 className="h-8 w-8 text-primary animate-spin" />
        </div>
      }>
        <Routes>
        <Route path="/" element={<SplashScreen />} />
        <Route path="/login" element={<LoginScreen />} />
        <Route path="/signup" element={<SignupScreen />} />
        <Route path="/terms" element={<TermsScreen />} />
        
        {/* Onboarding Flow */}
        <Route path="/onboarding/name" element={<ProtectedRoute><NameScreen /></ProtectedRoute>} />
        <Route path="/onboarding/details" element={<ProtectedRoute><PersonalDetailsScreen /></ProtectedRoute>} />
        <Route path="/onboarding/habits" element={<ProtectedRoute><DietHabitsScreen /></ProtectedRoute>} />
        <Route path="/onboarding/goal" element={<ProtectedRoute><GoalScreen /></ProtectedRoute>} />
        <Route path="/onboarding/activity-level" element={<ProtectedRoute><ActivityLevelScreen /></ProtectedRoute>} />
        <Route path="/onboarding/fitness-level" element={<ProtectedRoute><FitnessLevelScreen /></ProtectedRoute>} />

        {/* Main App */}
        <Route path="/home" element={<ProtectedRoute><DashboardScreen /></ProtectedRoute>} />
        <Route path="/dashboard" element={<Navigate to="/home" replace />} />
        <Route path="/diet" element={<ProtectedRoute><DietScreen /></ProtectedRoute>} />
        <Route path="/diet-history" element={<ProtectedRoute><DietHistoryScreen /></ProtectedRoute>} />
        <Route path="/workout" element={<ProtectedRoute><WorkoutScreen /></ProtectedRoute>} />
        <Route path="/progress" element={<ProtectedRoute><ProgressScreen /></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><ProfileScreen /></ProtectedRoute>} />
        <Route path="/history" element={<ProtectedRoute><WorkoutHistoryScreen /></ProtectedRoute>} />

        {/* Features */}
        <Route path="/settings" element={<ProtectedRoute><SettingsScreen /></ProtectedRoute>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </Suspense>
    </ErrorBoundary>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AppProvider>
  );
}
