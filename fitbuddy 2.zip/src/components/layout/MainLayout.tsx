import { ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Home, Utensils, Dumbbell, BarChart2, User } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { icon: Home, label: 'Home', path: '/dashboard' },
    { icon: Utensils, label: 'Diet', path: '/diet' },
    { icon: Dumbbell, label: 'Workouts', path: '/workout' },
    { icon: BarChart2, label: 'Stats', path: '/progress' },
    { icon: User, label: 'Profile', path: '/profile' },
  ];

  return (
    <MobileLayout className="pb-20 bg-background">
      <div className="flex-1 flex flex-col overflow-y-auto">
        {children}
      </div>

      {/* Bottom Navigation */}
      <div className="absolute bottom-0 left-0 right-0 bg-surface/90 backdrop-blur-md border-t border-surface-light h-20 px-6 flex items-center justify-between z-50">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center gap-1 w-12"
            >
              <div className={cn(
                "h-10 w-10 rounded-xl flex items-center justify-center transition-all",
                isActive ? "bg-primary text-black" : "text-text-muted hover:text-white"
              )}>
                <item.icon className="h-5 w-5" />
              </div>
              <span className={cn(
                "text-[10px] font-medium transition-colors",
                isActive ? "text-primary" : "text-text-muted"
              )}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </MobileLayout>
  );
}
