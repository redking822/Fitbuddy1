import { ReactNode } from 'react';
import { motion } from 'motion/react';

interface MobileLayoutProps {
  children: ReactNode;
  className?: string;
  showBottomNav?: boolean; // Placeholder for future bottom nav logic
}

export function MobileLayout({ children, className }: MobileLayoutProps) {
  return (
    <div className="min-h-screen w-full flex justify-center bg-black">
      <div className="w-full max-w-md bg-background min-h-screen relative shadow-2xl overflow-hidden flex flex-col">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className={`flex-1 flex flex-col ${className}`}
        >
          {children}
        </motion.div>
      </div>
    </div>
  );
}
