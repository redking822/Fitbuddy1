import { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { motion } from 'motion/react';

interface OnboardingLayoutProps {
  children: ReactNode;
  title: string;
  step: number;
  totalSteps: number;
  onBack?: () => void;
  showBack?: boolean;
}

export function OnboardingLayout({ 
  children, 
  title, 
  step, 
  totalSteps, 
  onBack,
  showBack = true 
}: OnboardingLayoutProps) {
  const navigate = useNavigate();
  const progress = (step / totalSteps) * 100;

  return (
    <MobileLayout className="p-6">
      <div className="flex items-center justify-between mb-6">
        {showBack ? (
          <Button variant="ghost" size="icon" onClick={onBack || (() => navigate(-1))}>
            <ChevronLeft className="h-6 w-6" />
          </Button>
        ) : (
          <div className="w-10" />
        )}
        <h1 className="text-lg font-semibold">{title}</h1>
        <div className="w-10" /> {/* Spacer for centering */}
      </div>

      <div className="mb-8">
        <div className="flex justify-between text-xs font-medium text-text-muted mb-2">
          <span>STEP {step} OF {totalSteps}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-1.5 w-full bg-surface-light rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="h-full bg-primary rounded-full"
          />
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.4 }}
        className="flex-1 flex flex-col"
      >
        {children}
      </motion.div>
    </MobileLayout>
  );
}
