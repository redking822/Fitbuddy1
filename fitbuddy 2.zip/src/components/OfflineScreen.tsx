import { WifiOff, RefreshCw } from 'lucide-react';
import { Button } from './ui/Button';

export default function OfflineScreen() {
  return (
    <div className="fixed inset-0 bg-background z-[9999] flex flex-col items-center justify-center p-6 text-center">
      <div className="h-24 w-24 rounded-[2rem] bg-surface-light flex items-center justify-center text-primary mb-8 shadow-inner">
        <WifiOff className="h-12 w-12" />
      </div>
      <h1 className="text-3xl font-black tracking-tighter mb-4 uppercase italic">Internet Required</h1>
      <p className="text-text-muted max-w-xs mb-10 font-medium leading-relaxed">
        FitBuddy needs an active internet connection to sync your progress and generate AI plans.
      </p>
      <Button 
        className="w-full h-16 text-lg font-bold rounded-2xl shadow-xl shadow-primary/20"
        onClick={() => window.location.reload()}
      >
        <RefreshCw className="h-5 w-5 mr-3" />
        Retry Connection
      </Button>
      <p className="mt-8 text-[10px] font-bold text-text-muted uppercase tracking-[0.2em]">FitBuddy AI Controller</p>
    </div>
  );
}
