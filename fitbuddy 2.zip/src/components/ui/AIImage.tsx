import React, { useState, useEffect } from 'react';
import { Dumbbell, Utensils, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getFoodImage, getExerciseImage } from '@/lib/imageMapping';

interface AIImageProps {
  type: 'exercise' | 'food';
  name: string;
  ingredients?: string[];
  className?: string;
  fallbackImage?: string;
}

export function AIImage({ type, name, ingredients = [], className, fallbackImage }: AIImageProps) {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    const localUrl = type === 'exercise' ? getExerciseImage(name) : getFoodImage(name);
    setImageUrl(localUrl);
    setLoading(false);
  }, [type, name]);

  if (loading) {
    return (
      <div className={cn("flex items-center justify-center bg-surface-light relative", className)}>
        {fallbackImage && !imageError && (
          <img 
            src={fallbackImage} 
            alt={name} 
            className="absolute inset-0 h-full w-full object-cover opacity-50"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
          />
        )}
        <Loader2 className="h-4 w-4 text-text-muted animate-spin relative z-10" />
      </div>
    );
  }

  if ((!imageUrl && !fallbackImage) || imageError) {
    return (
      <div className={cn("flex items-center justify-center bg-surface-light", className)}>
        {type === 'exercise' ? (
          <Dumbbell className="h-6 w-6 text-text-muted" />
        ) : (
          <Utensils className="h-6 w-6 text-text-muted" />
        )}
      </div>
    );
  }

  return (
    <img 
      src={imageUrl || fallbackImage} 
      alt={name} 
      className={cn("object-cover", className)}
      referrerPolicy="no-referrer"
      onError={() => setImageError(true)}
    />
  );
}
