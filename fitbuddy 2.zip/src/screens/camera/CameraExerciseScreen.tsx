import { useRef, useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Webcam from 'react-webcam';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { ChevronLeft, Camera, RefreshCcw, PlayCircle, PauseCircle, Maximize2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { cn } from '@/lib/utils';

export default function CameraExerciseScreen() {
  const navigate = useNavigate();
  const webcamRef = useRef<Webcam>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [repCount, setRepCount] = useState(0);
  const [feedback, setFeedback] = useState("Align your body in frame");
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Simulate rep counting logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        // Randomly increment reps for demo purposes
        if (Math.random() > 0.7) {
          setRepCount(prev => prev + 1);
          setFeedback("Good form! Keep going.");
        } else {
           setFeedback("Keep your back straight.");
        }
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const toggleCamera = useCallback(() => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  }, []);

  return (
    <MobileLayout className="bg-black h-full relative overflow-hidden">
      
      {/* Camera Feed */}
      <div className="absolute inset-0 z-0">
        <Webcam
          audio={false}
          ref={webcamRef}
          screenshotFormat="image/jpeg"
          videoConstraints={{
            facingMode: facingMode,
            width: 720,
            height: 1280
          }}
          className="h-full w-full object-cover"
          disablePictureInPicture={true}
          forceScreenshotSourceSize={true}
          imageSmoothing={true}
          mirrored={facingMode === 'user'}
          screenshotQuality={0.8}
          onUserMedia={() => {
            console.log('Camera started');
            setCameraError(null);
          }}
          onUserMediaError={(err) => {
            console.error('Camera error:', err);
            setCameraError("Camera permission denied. Please allow camera access in your browser settings.");
          }}
        />
        
        {cameraError && (
          <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/80 p-6 text-center">
            <div className="bg-red-500/20 p-4 rounded-full mb-4">
              <Camera className="h-8 w-8 text-red-500" />
            </div>
            <h3 className="text-white font-bold text-lg mb-2">Camera Access Required</h3>
            <p className="text-text-muted mb-6">{cameraError}</p>
            <Button onClick={() => window.location.reload()}>
              Retry Access
            </Button>
          </div>
        )}

        {/* Overlay UI - Skeleton / Grid (Visual only for now) */}
        <div className="absolute inset-0 pointer-events-none opacity-30">
           <div className="absolute top-1/4 left-1/4 right-1/4 bottom-1/4 border-2 border-dashed border-white rounded-3xl" />
           <div className="absolute top-1/2 left-0 right-0 h-px bg-white/50" />
           <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/50" />
        </div>
      </div>

      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-10 bg-gradient-to-b from-black/60 to-transparent">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="text-white hover:bg-white/20">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div className="bg-black/40 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/10">
          <span className="text-xs font-bold text-white uppercase tracking-wider">Squats</span>
        </div>
        <Button variant="ghost" size="icon" onClick={toggleCamera} className="text-white hover:bg-white/20">
          <RefreshCcw className="h-6 w-6" />
        </Button>
      </div>

      {/* Stats Overlay */}
      <div className="absolute top-20 left-4 z-10 space-y-2">
        <div className="bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/10 w-24">
          <p className="text-[10px] text-text-muted uppercase font-bold">REPS</p>
          <p className="text-3xl font-bold text-primary">{repCount}</p>
        </div>
        <div className="bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/10 w-24">
          <p className="text-[10px] text-text-muted uppercase font-bold">ACCURACY</p>
          <p className="text-xl font-bold text-green-400">94%</p>
        </div>
      </div>

      {/* Feedback Toast */}
      <div className="absolute bottom-32 left-0 right-0 flex justify-center z-10">
        <div className={cn(
          "px-6 py-3 rounded-full backdrop-blur-md border transition-all",
          feedback.includes("Good") 
            ? "bg-green-500/20 border-green-500/50 text-green-400" 
            : "bg-red-500/20 border-red-500/50 text-red-400"
        )}>
          <span className="font-bold text-sm">{feedback}</span>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-8 flex items-center justify-between z-10 bg-gradient-to-t from-black/80 to-transparent">
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 h-12 w-12 rounded-full">
          <Maximize2 className="h-6 w-6" />
        </Button>

        <button 
          onClick={() => setIsRecording(!isRecording)}
          className={cn(
            "h-20 w-20 rounded-full flex items-center justify-center transition-all transform hover:scale-105 active:scale-95",
            isRecording ? "bg-red-500" : "bg-primary"
          )}
        >
          {isRecording ? (
            <PauseCircle className="h-10 w-10 text-white fill-current" />
          ) : (
            <PlayCircle className="h-10 w-10 text-black fill-current" />
          )}
        </button>

        <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 h-12 w-12 rounded-full">
          <Camera className="h-6 w-6" />
        </Button>
      </div>

    </MobileLayout>
  );
}
