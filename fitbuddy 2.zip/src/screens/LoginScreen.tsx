import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/Button';
import { Dumbbell, CheckCircle2, AlertCircle, Mail, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '@/context/AppContext';
import { auth, googleProvider, signInWithPopup, signInWithRedirect, getRedirectResult, signInWithEmailAndPassword, sendPasswordResetEmail, setPersistence, browserLocalPersistence } from '@/lib/firebase';

export default function LoginScreen() {
  const navigate = useNavigate();
  const { user, isLoading: isAppLoading } = useApp();
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resetSent, setResetSent] = useState(false);

  // Auto-redirect if user is already logged in
  useEffect(() => {
    if (user && !isAppLoading) {
      if (user.isOnboarded) {
        navigate('/home');
      } else {
        navigate('/onboarding/name');
      }
    }
  }, [user, isAppLoading, navigate]);

  // Handle redirect result
  useEffect(() => {
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          // The auto-redirect effect will handle navigation
        }
      })
      .catch((err: any) => {
        console.error("Redirect Auth error:", err);
        if (err.code !== 'auth/popup-closed-by-user') {
          setError(`Login failed: ${err.message || "Please try again."}`);
        }
      });
  }, []);

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setResetSent(false);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      // The auto-redirect effect will handle navigation once AppContext fetches the user
    } catch (err: any) {
      console.error("Email Auth error:", err);
      let msg = "Login failed. Please check your credentials.";
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = "Invalid email or password. Please try again or reset your password.";
      } else if (err.code === 'auth/too-many-requests') {
        msg = "Too many failed attempts. Please try again later or reset your password.";
      }
      setError(msg);
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      setError("Please enter your email address first.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email);
      setResetSent(true);
      setError(null);
    } catch (err: any) {
      console.error("Reset error:", err);
      setError("Failed to send reset email. Please check the email address.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
      // The auto-redirect effect will handle navigation once AppContext fetches the user
    } catch (err: any) {
      console.error("Google Auth error:", err);
      if (err.code === 'auth/popup-closed-by-user' || err.code === 'auth/cancelled-popup-request' || err.code === 'auth/popup-blocked') {
        // Fallback to redirect
        try {
          await signInWithRedirect(auth, googleProvider);
        } catch (redirectErr: any) {
          console.error("Google Redirect error:", redirectErr);
          setError(`Google Sign-In failed: ${redirectErr.message || "Please try again."}`);
          setIsGoogleLoading(false);
        }
      } else if (err.code === 'auth/network-request-failed') {
        const isIframe = window !== window.top;
        if (isIframe) {
          setError("Google Sign-In is blocked by your browser inside this preview window. Please click the 'Open in new tab' button at the top right of AI Studio to sign in.");
        } else {
          setError("Network error. Please check your internet connection or disable ad blockers/trackers.");
        }
        setIsGoogleLoading(false);
      } else if (err.code === 'auth/unauthorized-domain') {
        setError("This domain is not authorized. Add it in Firebase Console -> Authentication -> Settings -> Authorized domains.");
        setIsGoogleLoading(false);
      } else if (err.code === 'auth/operation-not-allowed') {
        setError("Google Sign-In is not enabled. Enable it in Firebase Console -> Authentication -> Sign-in method.");
        setIsGoogleLoading(false);
      } else if (err.code === 'auth/web-storage-unsupported') {
        setError("Your browser is blocking third-party cookies required for sign-in. Please allow them or disable incognito mode.");
        setIsGoogleLoading(false);
      } else {
        setError(`Google Sign-In failed (${err.code}): ${err.message}`);
        setIsGoogleLoading(false);
      }
    }
  };

  return (
    <MobileLayout className="p-6">
      <div className="flex-1 flex flex-col">
        <div className="flex flex-col items-center justify-center mt-8 mb-10">
          <div className="h-20 w-20 rounded-2xl bg-surface-light flex items-center justify-center mb-6">
            <Dumbbell className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-3xl font-bold text-center">FitBuddy</h2>
          <p className="text-text-muted text-center max-w-xs mt-2">
            Your personal AI fitness companion
          </p>
        </div>

        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-2 text-red-500 text-sm bg-red-500/10 p-3 rounded-xl mb-6"
            >
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
              <span>{error}</span>
            </motion.div>
          )}
          {resetSent && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-2 text-primary text-sm bg-primary/10 p-3 rounded-xl mb-6"
            >
              <CheckCircle2 className="h-4 w-4 mt-0.5 shrink-0" />
              <span>Password reset email sent! Please check your inbox.</span>
            </motion.div>
          )}
        </AnimatePresence>

        <form onSubmit={handleEmailSignIn} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-text-muted ml-1 uppercase tracking-wider">Email</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-text-muted" />
              <input 
                type="email"
                required
                placeholder="name@example.com"
                className="w-full h-12 bg-surface-light rounded-xl pl-12 pr-4 text-white border border-transparent focus:border-primary outline-none transition-all"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (error) setError(null);
                }}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between items-center px-1">
              <label className="text-xs font-bold text-text-muted uppercase tracking-wider">Password</label>
              <button 
                type="button"
                onClick={handleForgotPassword}
                className="text-[10px] font-bold text-primary uppercase tracking-wider hover:underline"
              >
                Forgot?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-text-muted" />
              <input 
                type="password"
                required
                placeholder="••••••••"
                className="w-full h-12 bg-surface-light rounded-xl pl-12 pr-4 text-white border border-transparent focus:border-primary outline-none transition-all"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(null);
                }}
              />
            </div>
          </div>

          <Button 
            type="submit"
            className="w-full h-12" 
            isLoading={isLoading}
          >
            Sign In
          </Button>
        </form>

        <div className="flex items-center gap-4 my-8">
          <div className="h-px flex-1 bg-surface-light" />
          <span className="text-xs font-bold text-text-muted uppercase tracking-widest">OR</span>
          <div className="h-px flex-1 bg-surface-light" />
        </div>

        <Button 
          variant="outline"
          className="w-full bg-transparent border-surface-light text-white hover:bg-surface-light h-12" 
          onClick={handleGoogleSignIn}
          isLoading={isGoogleLoading}
        >
          <svg className="mr-3 h-5 w-5" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512">
            <path fill="currentColor" d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"></path>
          </svg>
          Continue with Google
        </Button>

        <div className="mt-8 text-center">
          <p className="text-sm text-text-muted">
            Don't have an account?{' '}
            <Link to="/signup" className="text-primary font-bold hover:underline">
              Sign Up
            </Link>
          </p>
        </div>
      </div>

      <div className="mt-auto pt-8 pb-4 text-center space-y-2">
        <div className="flex items-center justify-center gap-2 text-text-muted text-xs">
          <CheckCircle2 className="h-3 w-3" />
          <span>We never share your data.</span>
        </div>
      </div>
    </MobileLayout>
  );
}
