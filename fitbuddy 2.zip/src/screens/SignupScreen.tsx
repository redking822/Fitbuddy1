import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/Button';
import { Dumbbell, Mail, Lock, User, AlertCircle, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp, UserProfile } from '@/context/AppContext';
import { auth, db, createUserWithEmailAndPassword } from '@/lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

export default function SignupScreen() {
  const navigate = useNavigate();
  const { updateUser } = useApp();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const user = result.user;
      
      const today = new Date().toISOString().split('T')[0];
      const newUserData: UserProfile = {
        email: user.email || '',
        name: formData.name || 'User',
        age: 25,
        gender: 'Other',
        weight: 70,
        height: 170,
        diet: 'Mixed',
        goal: 'Weight Loss',
        activityLevel: 'Sedentary',
        fitnessLevel: 'Beginner',
        isOnboarded: false,
        termsAccepted: false,
        completedWorkouts: [],
        completedMeals: [],
        weightHistory: [],
        dailyStats: {
          dayId: Date.now().toString(),
          calories: 0,
          protein: 0,
          water: 0,
          workouts: 0,
          date: today,
          calorieTarget: 2000,
          proteinTarget: 150,
          completedExercises: [],
          isDayComplete: false
        }
      };
      
      await setDoc(doc(db, "users", user.uid), newUserData);
      updateUser(newUserData);
      navigate('/onboarding/name');
    } catch (err: any) {
      console.error("Signup error:", err);
      let msg = "Signup failed. Please try again.";
      if (err.code === 'auth/email-already-in-use') {
        msg = "This email is already registered. Please try signing in instead.";
      } else if (err.code === 'auth/weak-password') {
        msg = "Password should be at least 6 characters.";
      } else if (err.code === 'auth/invalid-email') {
        msg = "Invalid email address.";
      }
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <MobileLayout className="p-6">
      <div className="flex flex-col h-full">
        <button 
          onClick={() => navigate('/login')}
          className="h-10 w-10 rounded-full bg-surface-light flex items-center justify-center text-text-muted mb-6"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <div className="flex flex-col items-center mb-8">
          <div className="h-16 w-16 rounded-2xl bg-surface-light flex items-center justify-center mb-4">
            <Dumbbell className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-2xl font-bold">Create Account</h2>
          <p className="text-text-muted text-sm text-center mt-1">
            Join FitBuddy and start your fitness journey
          </p>
        </div>

        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-2 text-red-500 text-sm bg-red-500/10 p-3 rounded-xl mb-6"
            >
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
              <span>{error}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <form onSubmit={handleSignup} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-text-muted ml-1 uppercase tracking-wider">Full Name</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-text-muted" />
              <input 
                type="text"
                required
                placeholder="John Doe"
                className="w-full h-12 bg-surface-light rounded-xl pl-12 pr-4 text-white border border-transparent focus:border-primary outline-none transition-all"
                value={formData.name}
                onChange={(e) => {
                  setFormData({...formData, name: e.target.value});
                  if (error) setError(null);
                }}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-text-muted ml-1 uppercase tracking-wider">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-text-muted" />
              <input 
                type="email"
                required
                placeholder="name@example.com"
                className="w-full h-12 bg-surface-light rounded-xl pl-12 pr-4 text-white border border-transparent focus:border-primary outline-none transition-all"
                value={formData.email}
                onChange={(e) => {
                  setFormData({...formData, email: e.target.value});
                  if (error) setError(null);
                }}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-text-muted ml-1 uppercase tracking-wider">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-text-muted" />
              <input 
                type="password"
                required
                placeholder="••••••••"
                className="w-full h-12 bg-surface-light rounded-xl pl-12 pr-4 text-white border border-transparent focus:border-primary outline-none transition-all"
                value={formData.password}
                onChange={(e) => {
                  setFormData({...formData, password: e.target.value});
                  if (error) setError(null);
                }}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-text-muted ml-1 uppercase tracking-wider">Confirm Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-text-muted" />
              <input 
                type="password"
                required
                placeholder="••••••••"
                className="w-full h-12 bg-surface-light rounded-xl pl-12 pr-4 text-white border border-transparent focus:border-primary outline-none transition-all"
                value={formData.confirmPassword}
                onChange={(e) => {
                  setFormData({...formData, confirmPassword: e.target.value});
                  if (error) setError(null);
                }}
              />
            </div>
          </div>

          <Button 
            type="submit"
            className="w-full h-12 mt-4" 
            isLoading={isLoading}
          >
            Create Account
          </Button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-sm text-text-muted">
            Already have an account?{' '}
            <Link to="/login" className="text-primary font-bold hover:underline">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    </MobileLayout>
  );
}
