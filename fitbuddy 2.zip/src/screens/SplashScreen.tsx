import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Dumbbell } from 'lucide-react';
import { motion } from 'motion/react';
import { useApp } from '@/context/AppContext';

export default function SplashScreen() {
  const navigate = useNavigate();
  const { user, isLoading, termsAccepted } = useApp();

  useEffect(() => {
    if (isLoading) return;

    const timer = setTimeout(() => {
      if (!termsAccepted) {
        navigate('/terms');
        return;
      }

      if (user) {
        if (user.isOnboarded) {
          navigate('/home');
        } else {
          navigate('/onboarding/name');
        }
      } else {
        navigate('/login');
      }
    }, 800);

    return () => clearTimeout(timer);
  }, [navigate, user, isLoading, termsAccepted]);

  return (
    <MobileLayout className="items-center justify-center bg-background">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center gap-6"
      >
        <div className="h-24 w-24 rounded-full border-2 border-primary/30 flex items-center justify-center bg-surface relative">
           <motion.div 
             animate={{ scale: [1, 1.1, 1] }}
             transition={{ repeat: Infinity, duration: 2 }}
             className="absolute inset-0 rounded-full bg-primary/10"
           />
           <Dumbbell className="h-10 w-10 text-primary" />
        </div>
        
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white tracking-tight">
            Fit<span className="text-primary">Buddy</span>
          </h1>
          <p className="text-text-muted mt-2 text-sm tracking-widest uppercase">
            Your AI Fitness Companion
          </p>
        </div>
      </motion.div>
      
      <div className="absolute bottom-10 w-full px-10">
        <div className="h-1 w-full bg-surface-light rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
            className="h-full bg-primary"
          />
        </div>
        <p className="text-center text-xs text-text-muted mt-4 uppercase tracking-widest">Initializing</p>
      </div>
    </MobileLayout>
  );
}
