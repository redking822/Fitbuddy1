import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { OnboardingLayout } from '@/components/layout/OnboardingLayout';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { ArrowRight, Mars, Venus, Sparkles } from 'lucide-react'; // Using Sparkles as generic icon for 'Other'
import { useApp, UserGender } from '@/context/AppContext';
import { cn } from '@/lib/utils';

export default function PersonalDetailsScreen() {
  const navigate = useNavigate();
  const { updateUser } = useApp();
  const [gender, setGender] = useState<UserGender | null>(null);
  const [age, setAge] = useState(25);
  const [weight, setWeight] = useState(70);
  const [height, setHeight] = useState(170);
  const [error, setError] = useState<string | null>(null);

  const handleContinue = () => {
    if (gender) {
      if (age < 12 || age > 100) {
        setError("Please enter a valid age (12-100).");
        return;
      }
      if (weight < 30 || weight > 300) {
        setError("Please enter a valid weight (30-300kg).");
        return;
      }
      if (height < 100 || height > 250) {
        setError("Please enter a valid height (100-250cm).");
        return;
      }
      updateUser({ gender, age, weight, height });
      navigate('/onboarding/habits');
    }
  };

  const GenderOption = ({ type, icon: Icon, label }: { type: UserGender, icon: any, label: string }) => (
    <button
      onClick={() => setGender(type)}
      className={cn(
        "flex items-center justify-between w-full p-4 rounded-2xl border transition-all",
        gender === type 
          ? "border-primary bg-surface-light" 
          : "border-surface-light bg-surface hover:bg-surface-light/50"
      )}
    >
      <div className="flex items-center gap-4">
        <div className={cn(
          "h-10 w-10 rounded-xl flex items-center justify-center",
          gender === type ? "bg-primary text-black" : "bg-surface-light text-text-muted"
        )}>
          <Icon className="h-5 w-5" />
        </div>
        <span className="font-medium text-lg">{label}</span>
      </div>
      <div className={cn(
        "h-6 w-6 rounded-full border-2 flex items-center justify-center",
        gender === type ? "border-primary" : "border-text-muted"
      )}>
        {gender === type && <div className="h-3 w-3 rounded-full bg-primary" />}
      </div>
    </button>
  );

  return (
    <OnboardingLayout title="Personal Details" step={2} totalSteps={6}>
      <div className="flex-1 flex flex-col space-y-8">
        
        {/* Gender Selection */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">What's your gender?</h2>
          <p className="text-text-muted text-sm">
            This helps our AI calibrate your metabolic rate more accurately.
          </p>
          
          <div className="space-y-3">
            <GenderOption type="Male" icon={Mars} label="Male" />
            <GenderOption type="Female" icon={Venus} label="Female" />
            <GenderOption type="Other" icon={Sparkles} label="Other" />
          </div>
        </div>

        {/* Age Selection */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">How old are you?</h2>
          <p className="text-text-muted text-sm">
            Your age is a key factor in your daily energy expenditure.
          </p>
          
          <div className="relative h-24 flex items-center justify-center overflow-hidden">
            <div className="flex items-end justify-center gap-2 h-full w-full">
               {[...Array(7)].map((_, i) => {
                 const val = age - 3 + i;
                 const isCenter = i === 3;
                 return (
                   <div 
                    key={i} 
                    onClick={() => setAge(val)}
                    className={cn(
                      "flex flex-col items-center gap-1 cursor-pointer transition-all",
                      isCenter ? "scale-110 -translate-y-1" : "opacity-40 scale-90"
                    )}
                   >
                     <span className={cn(
                       "text-xl font-bold",
                       isCenter ? "text-primary text-2xl" : "text-text-muted"
                     )}>{val}</span>
                     <div className={cn(
                       "w-[2px] bg-primary rounded-full",
                       isCenter ? "h-8 bg-primary" : "h-4 bg-text-muted"
                     )} />
                   </div>
                 )
               })}
            </div>
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[2px] h-10 bg-primary z-10 pointer-events-none" />
          </div>
        </div>

        {/* Weight & Height Selection */}
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-bold">Weight (kg)</h3>
            <div className="flex items-center gap-3 bg-surface-light p-4 rounded-2xl border border-surface-light focus-within:border-primary transition-all">
              <input 
                type="number" 
                value={weight} 
                onChange={(e) => setWeight(Number(e.target.value))}
                className="bg-transparent w-full text-2xl font-bold outline-none"
              />
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-bold">Height (cm)</h3>
            <div className="flex items-center gap-3 bg-surface-light p-4 rounded-2xl border border-surface-light focus-within:border-primary transition-all">
              <input 
                type="number" 
                value={height} 
                onChange={(e) => setHeight(Number(e.target.value))}
                className="bg-transparent w-full text-2xl font-bold outline-none"
              />
            </div>
          </div>
        </div>

        <div className="mt-auto pt-6">
          <Button 
            className="w-full" 
            size="lg" 
            onClick={handleContinue}
            disabled={!gender}
          >
            Continue <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Modal isOpen={!!error} onClose={() => setError(null)} title="Invalid Input">
        <div className="text-center space-y-4">
          <p className="text-text-muted">{error}</p>
          <Button onClick={() => setError(null)} className="w-full bg-primary text-black hover:bg-primary/90">
            Close
          </Button>
        </div>
      </Modal>
    </OnboardingLayout>
  );
}
