import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { OnboardingLayout } from '@/components/layout/OnboardingLayout';
import { Button } from '@/components/ui/Button';
import { Zap, Activity, TrendingUp, Sparkles } from 'lucide-react';
import { useApp, FitnessLevel } from '@/context/AppContext';
import { cn } from '@/lib/utils';

export default function FitnessLevelScreen() {
  const navigate = useNavigate();
  const { updateUser } = useApp();
  const [level, setLevel] = useState<FitnessLevel | null>(null);

  const handleComplete = () => {
    if (level) {
      updateUser({ fitnessLevel: level, isOnboarded: true });
      navigate('/dashboard');
    }
  };

  const LevelCard = ({ type, icon: Icon, title, desc, popular }: { type: FitnessLevel, icon: any, title: string, desc: string, popular?: boolean }) => (
    <button
      onClick={() => setLevel(type)}
      className={cn(
        "relative w-full p-5 rounded-3xl border transition-all text-left group",
        level === type 
          ? "border-primary bg-surface-light" 
          : "border-surface-light bg-surface hover:bg-surface-light/50"
      )}
    >
      <div className="flex justify-between items-center">
        <div className="flex-1 pr-4">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="font-bold text-lg">{title}</h3>
            {popular && (
              <span className="bg-primary text-black text-[10px] font-bold px-2 py-0.5 rounded-full">POPULAR</span>
            )}
          </div>
          <p className="text-sm text-text-muted leading-relaxed">{desc}</p>
        </div>
        
        <div className={cn(
          "h-12 w-12 rounded-xl flex items-center justify-center transition-colors",
          level === type ? "bg-primary text-black" : "bg-surface-light text-text-muted group-hover:text-white"
        )}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </button>
  );

  return (
    <OnboardingLayout title="Set Profile" step={6} totalSteps={6}>
      <div className="flex-1 flex flex-col space-y-6">
        
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-text-muted uppercase">ONBOARDING STATUS</span>
            <span className="text-xs font-bold text-primary">100%</span>
          </div>
          <div className="h-1 w-full bg-surface-light rounded-full overflow-hidden">
            <div className="h-full bg-primary w-full" />
          </div>
        </div>

        <div className="space-y-2">
          <h2 className="text-3xl font-bold">What's your fitness level?</h2>
          <p className="text-text-muted text-sm">
            Our AI will tailor your initial workout intensity based on your selection.
          </p>
        </div>

        <div className="space-y-4 flex-1">
          <LevelCard 
            type="Beginner" 
            icon={Activity} 
            title="Beginner" 
            desc="New to training. Just getting started on my journey."
          />
          <LevelCard 
            type="Intermediate" 
            icon={TrendingUp} 
            title="Intermediate" 
            desc="Regularly active. I train 2-3 times a week."
            popular
          />
          <LevelCard 
            type="Advanced" 
            icon={Zap} 
            title="Advanced" 
            desc="Athlete level. Training is a core part of my lifestyle."
          />
        </div>

        {/* AI Calibration Complete Message */}
        <div className="bg-surface-light/40 rounded-2xl p-4 flex items-center gap-4">
           <div className="h-10 w-10 rounded-full bg-surface-light flex items-center justify-center text-primary">
             <Sparkles className="h-5 w-5" />
           </div>
           <div>
             <h4 className="font-bold text-sm text-white">AI Calibration Complete</h4>
             <p className="text-xs text-text-muted">Ready to generate your custom plan</p>
           </div>
        </div>

        <div className="mt-auto pt-6">
          <Button 
            className="w-full" 
            size="lg" 
            onClick={handleComplete}
            disabled={!level}
          >
            Complete Onboarding <Sparkles className="ml-2 h-4 w-4" />
          </Button>
          <p className="text-[10px] text-center text-text-muted mt-4 uppercase tracking-widest">
            Powered by Neural Fitness Engine V4.2
          </p>
        </div>
      </div>
    </OnboardingLayout>
  );
}
