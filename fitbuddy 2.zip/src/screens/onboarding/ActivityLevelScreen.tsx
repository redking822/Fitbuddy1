import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { OnboardingLayout } from '@/components/layout/OnboardingLayout';
import { Button } from '@/components/ui/Button';
import { ArrowRight, Coffee, BookOpen, GraduationCap, Briefcase, CheckCircle2, Clock, Calendar } from 'lucide-react';
import { useApp, ActivityLevel, Schedule } from '@/context/AppContext';
import { cn } from '@/lib/utils';

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function ActivityLevelScreen() {
  const navigate = useNavigate();
  const { updateUser } = useApp();
  const [activity, setActivity] = useState<ActivityLevel | null>(null);
  const [departureTime, setDepartureTime] = useState('08:00');
  const [returnTime, setReturnTime] = useState('17:00');
  const [holidays, setHolidays] = useState<string[]>(['Saturday', 'Sunday']);

  const handleContinue = () => {
    if (activity) {
      const schedule: Schedule | undefined = activity !== 'Sedentary' ? {
        departureTime,
        returnTime,
        holidays
      } : undefined;

      updateUser({ 
        activityLevel: activity,
        ...(schedule && { schedule })
      });
      navigate('/onboarding/fitness-level');
    }
  };

  const toggleHoliday = (day: string) => {
    setHolidays(prev => 
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const ActivityCard = ({ type, icon: Icon, title, desc, factor, image }: { type: ActivityLevel, icon: any, title: string, desc: string, factor: string, image: string }) => (
    <button
      onClick={() => setActivity(type)}
      className={cn(
        "relative w-full p-4 rounded-3xl border transition-all overflow-hidden group text-left h-36 shrink-0",
        activity === type 
          ? "border-primary bg-surface-light" 
          : "border-surface-light bg-surface hover:bg-surface-light/50"
      )}
    >
      {activity === type && (
        <div className="absolute top-2 right-2 z-20 text-primary">
          <CheckCircle2 className="h-5 w-5 fill-current" />
        </div>
      )}

      <div className="flex justify-between items-start relative z-10 h-full">
        <div className="max-w-[60%] flex flex-col h-full">
          <div className="flex items-center gap-2 mb-2">
            <Icon className={cn("h-5 w-5", activity === type ? "text-primary" : "text-text-muted")} />
            <span className="font-bold text-lg leading-none uppercase tracking-tight">{title}</span>
          </div>
          <p className="text-xs text-text-muted mb-2">{desc}</p>
          
          <div className="mt-auto flex items-center gap-1.5">
            <div className="h-1.5 w-1.5 rounded-full bg-primary" />
            <span className="text-[10px] font-bold text-text-muted uppercase tracking-wider">{factor}</span>
          </div>
        </div>
        
        <div className="absolute right-0 top-0 bottom-0 w-[35%]">
            <img 
              src={image} 
              alt={title} 
              className="h-full w-full object-cover opacity-90 group-hover:opacity-100 transition-opacity rounded-l-2xl"
              referrerPolicy="no-referrer"
            />
        </div>
      </div>
    </button>
  );

  return (
    <OnboardingLayout title="Lifestyle" step={4} totalSteps={5}>
      <div className="flex-1 flex flex-col space-y-6 overflow-y-auto pb-24 no-scrollbar">
        
        <div className="space-y-2 shrink-0">
          <h2 className="text-3xl font-bold">What's your lifestyle?</h2>
          <p className="text-text-muted text-sm">
            This helps our AI calculate your TDEE and plan your meals and workouts around your schedule.
          </p>
        </div>

        <div className="space-y-4 shrink-0">
          <ActivityCard 
            type="Sedentary" 
            icon={Coffee} 
            title="Sedentary" 
            desc="Little to no exercise, mostly sitting at home."
            factor="FACTOR: 1.2x BMR"
            image="https://picsum.photos/seed/sedentary/200/200"
          />
          <ActivityCard 
            type="School Student" 
            icon={BookOpen} 
            title="School Student" 
            desc="Attends school daily. Moderate activity walking between classes."
            factor="FACTOR: 1.4x BMR"
            image="https://picsum.photos/seed/school/200/200"
          />
          <ActivityCard 
            type="College Student" 
            icon={GraduationCap} 
            title="College Student" 
            desc="Attends lectures, walks around campus, varied daily schedule."
            factor="FACTOR: 1.5x BMR"
            image="https://picsum.photos/seed/college/200/200"
          />
          <ActivityCard 
            type="Office Worker" 
            icon={Briefcase} 
            title="Office Worker" 
            desc="Standard work hours, commutes daily, mostly sedentary at work."
            factor="FACTOR: 1.3x BMR"
            image="https://picsum.photos/seed/office/200/200"
          />
        </div>

        {activity && activity !== 'Sedentary' && (
          <div className="bg-surface border border-surface-light rounded-3xl p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Your Daily Schedule
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-text-muted uppercase tracking-wider">Departure Time</label>
                <input 
                  type="time" 
                  value={departureTime}
                  onChange={(e) => setDepartureTime(e.target.value)}
                  className="w-full bg-surface-light border border-surface-light rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-text-muted uppercase tracking-wider">Return Time</label>
                <input 
                  type="time" 
                  value={returnTime}
                  onChange={(e) => setReturnTime(e.target.value)}
                  className="w-full bg-surface-light border border-surface-light rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors"
                />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-text-muted flex items-center gap-2 uppercase tracking-wider">
                <Calendar className="h-4 w-4" />
                Select Holidays (Days Off)
              </label>
              <div className="flex flex-wrap gap-2">
                {DAYS_OF_WEEK.map(day => (
                  <button
                    key={day}
                    onClick={() => toggleHoliday(day)}
                    className={cn(
                      "px-4 py-2 rounded-xl text-sm font-medium transition-colors border",
                      holidays.includes(day)
                        ? "bg-primary text-black border-primary"
                        : "bg-surface-light text-text-muted border-surface-light hover:border-text-muted"
                    )}
                  >
                    {day.substring(0, 3)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background via-background to-transparent z-50">
          <Button 
            className="w-full max-w-md mx-auto flex" 
            size="lg" 
            onClick={handleContinue}
            disabled={!activity}
          >
            Continue <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </OnboardingLayout>
  );
}
