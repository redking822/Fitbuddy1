import { UserProfile } from '@/context/AppContext';

export const CALORIE_LEVELS = {
  LOW: 300,
  MEDIUM: 400,
  HIGH: 500
};

export const calculateDailyTarget = (user: UserProfile): number => {
  // 1. Calculate BMR (Mifflin-St Jeor Equation)
  let bmr = 0;
  const weight = user.weight || 70;
  const height = user.height || 170;
  const age = user.age || 25;

  if (user.gender === 'Male') {
    bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5;
  } else if (user.gender === 'Female') {
    bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161;
  } else {
    // Average for 'Other' to provide a reasonable baseline
    bmr = (10 * weight) + (6.25 * height) - (5 * age) - 78;
  }

  // 2. Multiply with Activity Factor -> TDEE
  // Activity Levels: Sedentary (1.2), Office Worker (1.3), School Student (1.4), College Student (1.5)
  let activityFactor = 1.2;
  if (user.activityLevel === 'Office Worker') activityFactor = 1.3;
  if (user.activityLevel === 'School Student') activityFactor = 1.4;
  if (user.activityLevel === 'College Student') activityFactor = 1.5;
  
  const tdee = bmr * activityFactor;
  let target = tdee;

  // 3. Adjust based on goal (STRICT)
  if (user.goal === 'Weight Loss') {
    target -= 400; // TDEE - 400 (Range: 300-500)
  } else if (user.goal === 'Muscle Building') {
    target += 400; // TDEE + 400 (Range: 300-500)
  } else if (user.goal === 'Weight Gain') {
    target += 550; // TDEE + 550 (Range: 400-700)
  }

  // Ensure a minimum calorie floor for health
  return Math.max(Math.round(target), 1200);
};

export const calculateProteinTarget = (user: { weight: number; goal: string }): number => {
  const weight = user.weight || 70;
  const goal = user.goal || 'Muscle Building';

  // 4. Protein Calculation (STRICT)
  if (goal === 'Weight Loss') {
    return Math.round(weight * 1.9); // Range: 1.6-2.2
  } else if (goal === 'Muscle Building') {
    return Math.round(weight * 2.1); // Range: 1.8-2.5
  } else if (goal === 'Weight Gain') {
    return Math.round(weight * 1.8); // Range: 1.5-2.2
  }

  return Math.round(weight * 1.8); // Default
};
