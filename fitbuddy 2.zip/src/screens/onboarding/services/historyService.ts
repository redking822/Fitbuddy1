import { db } from '@/lib/firebase';
import { collection, addDoc, serverTimestamp, query, where, getDocs, Timestamp, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '@/lib/firestoreUtils';

export interface DietHistoryEntry {
  id?: string;
  mealName: string;
  calories: number;
  protein?: number;
  completedAt: Timestamp;
}

export const logMealToHistory = async (userId: string, mealName: string, calories: number, protein: number = 0) => {
  const historyPath = `users/${userId}/diet_history`;
  try {
    const historyRef = collection(db, 'users', userId, 'diet_history');
    
    // Check for duplicate entry today (optional but good for Feature 8)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const q = query(
      historyRef, 
      where('mealName', '==', mealName),
      where('completedAt', '>=', Timestamp.fromDate(today))
    );
    
    const querySnapshot = await getDocs(q);
    if (!querySnapshot.empty) {
      throw new Error("Meal already completed today");
    }

    await addDoc(historyRef, {
      mealName,
      calories,
      protein,
      completedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, historyPath);
  }
};

export const getDailyCaloriesConsumed = async (userId: string): Promise<number> => {
  const historyPath = `users/${userId}/diet_history`;
  try {
    const historyRef = collection(db, 'users', userId, 'diet_history');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const q = query(
      historyRef, 
      where('completedAt', '>=', Timestamp.fromDate(today))
    );
    
    const querySnapshot = await getDocs(q);
    let total = 0;
    querySnapshot.forEach((doc) => {
      total += doc.data().calories || 0;
    });
    
    return total;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, historyPath);
    return 0;
  }
};

export const getDietHistory = async (userId: string): Promise<DietHistoryEntry[]> => {
  const historyPath = `users/${userId}/diet_history`;
  try {
    const historyRef = collection(db, 'users', userId, 'diet_history');
    const q = query(historyRef, orderBy('completedAt', 'desc'));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as DietHistoryEntry[];
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, historyPath);
    return [];
  }
};

export const deleteDietEntry = async (userId: string, entryId: string) => {
  const entryPath = `users/${userId}/diet_history/${entryId}`;
  try {
    const entryRef = doc(db, 'users', userId, 'diet_history', entryId);
    await deleteDoc(entryRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, entryPath);
  }
};

export const deleteWorkoutEntry = async (userId: string, entryId: string) => {
  const entryPath = `workout_history/${userId}/workouts/${entryId}`;
  try {
    const entryRef = doc(db, 'workout_history', userId, 'workouts', entryId);
    await deleteDoc(entryRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, entryPath);
  }
};

export const clearUserHistory = async (userId: string) => {
  try {
    // Clear diet history
    const dietRef = collection(db, 'users', userId, 'diet_history');
    const dietSnapshot = await getDocs(dietRef);
    const dietDeletes = dietSnapshot.docs.map(doc => deleteDoc(doc.ref));
    
    // Clear workout history
    const workoutRef = collection(db, 'workout_history', userId, 'workouts');
    const workoutSnapshot = await getDocs(workoutRef);
    const workoutDeletes = workoutSnapshot.docs.map(doc => deleteDoc(doc.ref));
    
    await Promise.all([...dietDeletes, ...workoutDeletes]);
  } catch (error) {
    console.error("Error clearing user history:", error);
  }
};
