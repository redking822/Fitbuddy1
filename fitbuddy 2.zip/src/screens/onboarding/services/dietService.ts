import { db } from '@/lib/firebase';
import { collection, getDocs, doc, setDoc, query, limit } from 'firebase/firestore';
import { Meal } from '@/context/AppContext';

export const getDietPlan = async (userId: string): Promise<Meal[]> => {
  try {
    const dietPlansRef = collection(db, 'users', userId, 'diet_plans');
    const q = query(dietPlansRef, limit(10));
    const querySnapshot = await getDocs(q);
    
    const meals: Meal[] = [];
    querySnapshot.forEach((doc) => {
      meals.push({ id: doc.id, ...doc.data() } as any);
    });
    
    return meals;
  } catch (error) {
    console.error("Error fetching diet plan:", error);
    return [];
  }
};

export const saveDietPlan = async (userId: string, meals: Meal[]) => {
  try {
    const dietPlansRef = collection(db, 'users', userId, 'diet_plans');
    for (const meal of meals) {
      const mealDocRef = doc(dietPlansRef);
      await setDoc(mealDocRef, meal);
    }
  } catch (error) {
    console.error("Error saving diet plan:", error);
  }
};
