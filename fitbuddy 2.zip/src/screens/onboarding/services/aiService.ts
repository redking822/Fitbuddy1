import { UserProfile, DietPlan, WorkoutPlan, Meal, WorkoutExercise, GroceryItem } from '@/context/AppContext';
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { calculateDailyTarget, calculateProteinTarget } from './calorieService';

let aiInstance: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("AI API Key is missing. Please configure it in your settings.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

async function callFallbackAI(prompt: string, schema: any): Promise<any> {
  // Mock fallback AI implementation for demonstration
  console.log("Calling Fallback AI...");
  throw new Error("Fallback AI not implemented");
}

async function generateWithFallback(prompt: string, schema: any, model: string = "gemini-3-flash-preview"): Promise<any> {
  let lastError;
  for (let i = 0; i < 3; i++) {
    try {
      const ai = getAIClient();
      const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
        }
      });
      
      if (!response.text) {
        throw new Error("Empty response from AI");
      }
      
      return JSON.parse(response.text);
    } catch (error: any) {
      lastError = error;
      const errorMsg = error?.message?.toLowerCase() || "";
      console.error(`AI Generation Attempt ${i + 1} failed:`, error);
      
      if (errorMsg.includes("quota") || errorMsg.includes("rate") || errorMsg.includes("429")) {
        console.warn("Gemini quota exceeded, switching to fallback AI...");
        return await callFallbackAI(prompt, schema);
      }
      
      // If it's a 500 or network error, wait and retry
      if (i < 2) {
        const delay = 1000 * (i + 1);
        console.log(`Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  throw lastError;
}

export const generateDietPlan = async (user: UserProfile): Promise<DietPlan> => {
  const totalCalories = calculateDailyTarget(user);
  const totalProtein = calculateProteinTarget(user);
  
  const prompt = `You are the CORE AI CONTROLLER for the FitBuddy application.
  Generate a NEW 7-DAY diet plan (Monday to Sunday) for a user with the following profile:
  - Weight: ${user.weight}kg
  - Height: ${user.height}cm
  - Age: ${user.age}
  - Gender: ${user.gender}
  - Goal: ${user.goal}
  - Diet Type: ${user.diet}
  - Lifestyle: ${user.activityLevel}
  ${user.schedule ? `- Schedule: Leaves home at ${user.schedule.departureTime}, returns at ${user.schedule.returnTime}. Holidays: ${user.schedule.holidays.join(', ')}` : ''}

  CRITICAL REQUIREMENT: EVERY SINGLE DAY MUST BE COMPLETELY UNIQUE.
  DO NOT REPEAT MEALS ACROSS DIFFERENT DAYS. 
  Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, and Sunday MUST all have DIFFERENT breakfast, lunch, snack, and dinner options. Do not repeat the same daily plan after a gap.

  STRICT NUTRITIONAL REQUIREMENTS PER DAY:
  - Total Daily Calories: ${totalCalories} kcal
  - Total Daily Protein: ${totalProtein} g
  
  MEAL STRUCTURE AND REALISTIC CALORIE DISTRIBUTION PER DAY:
  - Breakfast (approx 20% of total calories)
  - Lunch (approx 35% of total calories)
  - Snack (approx 10% of total calories)
  - Dinner (approx 35% of total calories)
  - Divide total protein realistically across these 4 meals.
  - Each meal MUST include: food name, quantity (e.g., "200g"), calories, and protein.
  - NO IMAGES.
  - Total calories & protein MUST match the targets exactly for EACH day.
  - Use REALISTIC food data only.
  `;

  const mealSchema = {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING },
      ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
      protein: { type: Type.NUMBER },
      calories: { type: Type.NUMBER },
      energy: { type: Type.STRING },
      portionSize: { type: Type.STRING },
      quantity: { type: Type.STRING },
      preparation: { type: Type.STRING }
    },
    required: ["name", "ingredients", "protein", "calories", "energy", "portionSize", "quantity", "preparation"]
  };

  const schema = {
    type: Type.OBJECT,
    properties: {
      days: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            day: { type: Type.STRING, description: "e.g., Monday, Tuesday" },
            breakfast: mealSchema,
            lunch: mealSchema,
            snack: mealSchema,
            dinner: mealSchema,
            dailyNutritionSummary: {
              type: Type.OBJECT,
              properties: {
                totalCalories: { type: Type.NUMBER },
                totalProtein: { type: Type.NUMBER }
              },
              required: ["totalCalories", "totalProtein"]
            }
          },
          required: ["day", "breakfast", "lunch", "snack", "dinner", "dailyNutritionSummary"]
        }
      },
      groceryList: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            category: { type: Type.STRING, enum: ["Vegetables", "Fruits", "Grains", "Protein Sources", "Dairy", "Other Ingredients"] }
          },
          required: ["name", "category"]
        }
      }
    },
    required: ["days", "groceryList"]
  };

  const plan = await generateWithFallback(prompt, schema);
  
  // Add YouTube tutorial links for each meal recipe
  plan.days.forEach((dayPlan: any) => {
    if (dayPlan.breakfast) dayPlan.breakfast.tutorialUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(dayPlan.breakfast.name + " healthy recipe")}`;
    if (dayPlan.lunch) dayPlan.lunch.tutorialUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(dayPlan.lunch.name + " healthy recipe")}`;
    if (dayPlan.snack) dayPlan.snack.tutorialUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(dayPlan.snack.name + " healthy recipe")}`;
    if (dayPlan.dinner) dayPlan.dinner.tutorialUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(dayPlan.dinner.name + " healthy recipe")}`;
  });

  return plan;
};

export const generateWorkoutPlan = async (user: UserProfile): Promise<WorkoutPlan> => {
  let workoutType = "strength training";
  if (user.goal === 'Weight Loss') workoutType = "cardio + HIIT";
  else if (user.goal === 'Weight Gain') workoutType = "light strength + recovery focus";

  const prompt = `You are the CORE AI CONTROLLER for the FitBuddy application.
  Generate a NEW 7-DAY workout plan (Monday to Sunday) for a user with the following profile:
  - Age: ${user.age}
  - Goal: ${user.goal}
  - Level: ${user.fitnessLevel}
  - Lifestyle: ${user.activityLevel}
  ${user.schedule ? `- Schedule: Leaves home at ${user.schedule.departureTime}, returns at ${user.schedule.returnTime}. Holidays: ${user.schedule.holidays.join(', ')}` : ''}
  
  CRITICAL REQUIREMENT: EVERY SINGLE ACTIVE DAY MUST HAVE A COMPLETELY UNIQUE WORKOUT ROUTINE.
  DO NOT REPEAT THE EXACT SAME WORKOUT ON DIFFERENT DAYS.
  Target different muscle groups or use different exercises for each active day to ensure a varied 7-day schedule. Do not repeat the same daily plan after a gap.

  STRICT WORKOUT TYPE: ${workoutType}
  
  STRUCTURE:
  - 7 days total (Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday).
  - EVERY SINGLE DAY MUST BE AN ACTIVE WORKOUT DAY. 
  - STRICTLY FORBIDDEN: DO NOT INCLUDE ANY REST DAYS. 
  - 'isRestDay' MUST BE FALSE for all 7 days.
  - Saturday and Sunday MUST have full, unique workout routines.
  - For each day: Warmup, Main Workout (4-6 exercises), Cooldown.
  - Each exercise MUST include: name, sets, reps, rest time, and instructions.
  - NO IMAGES.
  - NO camera/AI form detection.
  `;

  const exerciseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING },
        sets: { type: Type.NUMBER },
        reps: { type: Type.STRING },
        restTime: { type: Type.STRING },
        instruction: { type: Type.STRING }
      },
      required: ["name", "sets", "reps", "restTime", "instruction"]
    }
  };

  const schema = {
    type: Type.OBJECT,
    properties: {
      days: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            day: { type: Type.STRING, description: "e.g., Monday, Tuesday" },
            title: { type: Type.STRING },
            duration: { type: Type.STRING },
            isRestDay: { type: Type.BOOLEAN },
            warmup: exerciseSchema,
            mainExercises: exerciseSchema,
            cooldown: exerciseSchema,
            motivationalMessage: { type: Type.STRING }
          },
          required: ["day", "title", "duration", "isRestDay", "warmup", "mainExercises", "cooldown", "motivationalMessage"]
        }
      }
    },
    required: ["days"]
  };

  const plan = await generateWithFallback(prompt, schema);

  const processExercises = (exercises: any[]) => {
    if (!exercises) return [];
    return exercises.map((ex: any) => ({
      ...ex,
      tutorialUrl: `https://www.youtube.com/results?search_query=${encodeURIComponent(ex.name + " tutorial")}`
    }));
  };

  plan.days.forEach((dayPlan: any) => {
    dayPlan.warmup = processExercises(dayPlan.warmup);
    dayPlan.mainExercises = processExercises(dayPlan.mainExercises);
    dayPlan.cooldown = processExercises(dayPlan.cooldown);
  });
  
  return plan;
};
