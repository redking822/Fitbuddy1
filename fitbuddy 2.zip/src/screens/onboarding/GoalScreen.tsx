import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { OnboardingLayout } from '@/components/layout/OnboardingLayout';
import { Button } from '@/components/ui/Button';
import { ArrowRight, CheckCircle2, Scale, Dumbbell, Beef } from 'lucide-react';
import { useApp, FitnessGoal } from '@/context/AppContext';
import { cn } from '@/lib/utils';

export default function GoalScreen() {
  const navigate = useNavigate();
  const { updateUser } = useApp();
  const [goal, setGoal] = useState<FitnessGoal | null>(null);

  const handleContinue = () => {
    if (goal) {
      updateUser({ goal });
      navigate('/onboarding/activity-level');
    }
  };

  const GoalCard = ({ type, icon: Icon, title, desc, image }: { type: FitnessGoal, icon: any, title: string, desc: string, image: string }) => (
    <button
      onClick={() => setGoal(type)}
      className={cn(
        "relative w-full p-4 rounded-3xl border transition-all overflow-hidden group text-left h-32",
        goal === type 
          ? "border-primary bg-surface-light" 
          : "border-surface-light bg-surface hover:bg-surface-light/50"
      )}
    >
      <div className="flex justify-between items-start relative z-10">
        <div className="max-w-[60%]">
          <div className="flex items-center gap-2 mb-2">
            <div className={cn(
              "p-1.5 rounded-lg",
              goal === type ? "bg-primary text-black" : "bg-surface-light text-text-muted"
            )}>
              <Icon className="h-4 w-4" />
            </div>
            <span className="font-bold text-lg leading-none">{title}</span>
          </div>
          <p className="text-xs text-text-muted">{desc}</p>
          
          {goal === type && (
            <div className="flex items-center gap-1 text-primary text-xs font-bold mt-3">
              <CheckCircle2 className="h-3 w-3" />
              <span>Current Focus</span>
            </div>
          )}
        </div>
        
        {/* Image Placeholder */}
        <div className="absolute right-0 top-0 bottom-0 w-[35%] bg-black/20">
            <img 
              src={image} 
              alt={title} 
              className="h-full w-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent to-surface/80" />
        </div>
      </div>
    </button>
  );

  return (
    <OnboardingLayout title="Fitness Goal" step={4} totalSteps={6}>
      <div className="flex-1 flex flex-col space-y-6">
        
        <div className="space-y-2">
          <h2 className="text-3xl font-bold">What's your goal?</h2>
          <p className="text-text-muted text-sm">
            We'll tailor your experience based on your selection.
          </p>
        </div>

        <div className="space-y-4 flex-1">
          <GoalCard 
            type="Weight Loss" 
            icon={Scale} 
            title="WEIGHT LOSS" 
            desc="Burn fat, improve metabolic health, and get lean."
            image="https://picsum.photos/seed/fitness1/200/200"
          />
          <GoalCard 
            type="Muscle Building" 
            icon={Dumbbell} 
            title="MUSCLE BUILDING" 
            desc="Hypertrophy training to increase strength and size."
            image="https://picsum.photos/seed/fitness2/200/200"
          />
          <GoalCard 
            type="Weight Gain" 
            icon={Beef} 
            title="WEIGHT GAIN" 
            desc="Healthy bulk strategies and caloric surplus nutrition."
            image="https://picsum.photos/seed/fitness3/200/200"
          />
        </div>

        <div className="mt-auto pt-6">
          <Button 
            className="w-full" 
            size="lg" 
            onClick={handleContinue}
            disabled={!goal}
          >
            Continue <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </OnboardingLayout>
  );
}
