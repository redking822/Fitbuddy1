import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { OnboardingLayout } from '@/components/layout/OnboardingLayout';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { ArrowRight, User } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { motion } from 'motion/react';

export default function NameScreen() {
  const navigate = useNavigate();
  const { updateUser } = useApp();
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleContinue = () => {
    if (name.trim()) {
      if (name.trim().length < 2) {
        setError("Please enter a valid name (at least 2 characters).");
        return;
      }
      updateUser({ name });
      navigate('/onboarding/details');
    }
  };

  return (
    <OnboardingLayout title="Setup Profile" step={1} totalSteps={6} showBack={false}>
      <div className="flex-1 flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-32 h-32 bg-surface-light rounded-full flex items-center justify-center mb-8 border border-primary/20">
            <User className="w-16 h-16 text-primary" />
          </div>

          <h2 className="text-3xl font-bold mb-2 text-center">Let's get started</h2>
          <p className="text-text-muted text-center mb-8">
            First, how should we call you?
          </p>

          <div className="w-full space-y-2">
            <label className="text-xs font-bold tracking-wider text-text-muted uppercase ml-1">Full Name</label>
            <Input 
              placeholder="Enter your name" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-surface-light border-transparent focus:border-primary"
            />
          </div>
        </div>

        <div className="mt-auto pt-6">
          <Button 
            className="w-full" 
            size="lg" 
            onClick={handleContinue}
            disabled={!name.trim()}
          >
            Continue <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Modal isOpen={!!error} onClose={() => setError(null)} title="Invalid Input">
        <div className="text-center space-y-4">
          <p className="text-text-muted">{error}</p>
          <Button onClick={() => setError(null)} className="w-full bg-primary text-black hover:bg-primary/90">
            Close
          </Button>
        </div>
      </Modal>
    </OnboardingLayout>
  );
}
