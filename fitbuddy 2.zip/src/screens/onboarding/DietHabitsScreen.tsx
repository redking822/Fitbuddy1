import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { OnboardingLayout } from '@/components/layout/OnboardingLayout';
import { Button } from '@/components/ui/Button';
import { ArrowRight, Leaf, Utensils, UtensilsCrossed, Moon, Droplets, Bot } from 'lucide-react';
import { useApp, DietType } from '@/context/AppContext';
import { cn } from '@/lib/utils';
import { motion } from 'motion/react';

export default function DietHabitsScreen() {
  const navigate = useNavigate();
  const { updateUser } = useApp();
  const [diet, setDiet] = useState<DietType>('Veg');
  const [sleep, setSleep] = useState(7.5);
  const [water, setWater] = useState(6);

  const handleContinue = () => {
    updateUser({ diet });
    navigate('/onboarding/goal');
  };

  const DietOption = ({ type, icon: Icon, label }: { type: DietType, icon: any, label: string }) => (
    <button
      onClick={() => setDiet(type)}
      className={cn(
        "flex flex-col items-center justify-center p-4 rounded-2xl border transition-all h-28 w-full",
        diet === type 
          ? "border-primary bg-surface-light text-primary" 
          : "border-surface-light bg-surface text-text-muted hover:bg-surface-light/50"
      )}
    >
      <Icon className="h-6 w-6 mb-2" />
      <span className="font-medium text-sm">{label}</span>
    </button>
  );

  return (
    <OnboardingLayout title="Dietary Habits" step={3} totalSteps={6}>
      <div className="flex-1 flex flex-col space-y-8 overflow-y-auto pb-4">
        
        {/* Diet Selection */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <UtensilsCrossed className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-bold">Current Diet</h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <DietOption type="Veg" icon={Leaf} label="Veg" />
            <DietOption type="Non-Veg" icon={Utensils} label="Non-Veg" />
            <DietOption type="Mixed" icon={UtensilsCrossed} label="Mixed" />
          </div>
        </div>

        {/* Sleep Slider */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Moon className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-bold">Daily Sleep</h2>
            </div>
            <span className="text-primary font-bold text-xl">{sleep} <span className="text-sm text-text-muted font-normal">hours</span></span>
          </div>
          
          <div className="bg-surface-light rounded-2xl p-6 relative">
            <input 
              type="range" 
              min="4" 
              max="12" 
              step="0.5"
              value={sleep}
              onChange={(e) => setSleep(parseFloat(e.target.value))}
              className="w-full accent-primary h-2 bg-surface rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-xs text-text-muted mt-2 px-1">
              <span>4h</span>
              <span>8h</span>
              <span>12h</span>
            </div>
          </div>
        </div>

        {/* Water Intake */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Droplets className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-bold">Water Intake</h2>
            </div>
            <span className="text-primary font-bold text-xl">{water} <span className="text-sm text-text-muted font-normal">/ 10 glasses</span></span>
          </div>
          
          <div className="bg-surface-light rounded-2xl p-6">
            <div className="flex justify-between mb-4 px-2">
              {[...Array(10)].map((_, i) => (
                <div 
                  key={i}
                  className={cn(
                    "w-3 h-4 rounded-sm transition-all",
                    i < water ? "bg-primary" : "bg-surface/50"
                  )}
                  style={{
                    clipPath: "polygon(0 0, 100% 0, 85% 100%, 15% 100%)"
                  }}
                />
              ))}
            </div>
            <input 
              type="range" 
              min="0" 
              max="10" 
              step="1"
              value={water}
              onChange={(e) => setWater(parseInt(e.target.value))}
              className="w-full accent-primary h-2 bg-surface rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        {/* AI Insight Card */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-surface-light/50 border border-primary/20 rounded-2xl p-4 flex gap-4"
        >
          <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center shrink-0">
            <Bot className="h-6 w-6 text-black" />
          </div>
          <div>
            <h4 className="text-primary text-sm font-bold mb-1">AI Health Insight</h4>
            <p className="text-xs text-text-muted leading-relaxed">
              Based on your sleep pattern, increasing your water intake by 2 more glasses before 6 PM could improve your REM cycle tonight.
            </p>
          </div>
        </motion.div>

        <div className="mt-auto pt-4">
          <Button 
            className="w-full" 
            size="lg" 
            onClick={handleContinue}
          >
            Continue <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </OnboardingLayout>
  );
}
