import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { ChevronLeft, Flame, Dumbbell, CheckCircle2, Clock, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { collection, query, orderBy, getDocs } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { cn } from '@/lib/utils';
import { deleteWorkoutEntry } from '@/screens/onboarding/services/historyService';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';

interface HistoryItem {
  id: string;
  title: string;
  date: string;
  duration: string;
  calories: number;
  exercises: number;
  status: string;
}

export default function WorkoutHistoryScreen() {
  const navigate = useNavigate();
  const { user } = useApp();
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'All' | 'Today' | 'Week' | 'Month'>('All');
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteEntry, setDeleteEntry] = useState<{id: string, title: string} | null>(null);

  const fetchHistory = async () => {
    if (!auth.currentUser) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'workout_history', auth.currentUser.uid, 'workouts'),
        orderBy('date', 'desc')
      );
      const snapshot = await getDocs(q);
      
      if (!snapshot.empty) {
        const data = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as HistoryItem[];
        setHistory(data);
      } else {
        // Fallback to local user.completedWorkouts if firestore is empty
        loadFallbackHistory();
      }
    } catch (error) {
      console.error("Error fetching history:", error);
      loadFallbackHistory();
    } finally {
      setLoading(false);
    }
  };

  const loadFallbackHistory = () => {
    if (user?.completedWorkouts) {
      const fallbackData = user.completedWorkouts.map((w: string | import('@/context/AppContext').CompletedWorkout, idx) => {
        if (typeof w === 'string') {
          return {
            id: `fallback-${idx}`,
            title: 'Daily Workout',
            date: new Date(w).toISOString(),
            duration: '30 Min',
            calories: 250,
            exercises: 5,
            status: 'Completed'
          };
        }
        return {
          id: `fallback-${idx}`,
          title: w.title,
          date: new Date(w.date).toISOString(),
          duration: w.duration,
          calories: 300,
          exercises: 8,
          status: w.status
        };
      }).reverse();
      setHistory(fallbackData);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [user]);

  const handleDelete = async () => {
    if (!auth.currentUser || !deleteEntry) return;
    
    setIsDeleting(true);
    try {
      // Only attempt to delete from Firestore if it's not a fallback entry
      if (!deleteEntry.id.startsWith('fallback-')) {
        await deleteWorkoutEntry(auth.currentUser.uid, deleteEntry.id);
      }
      setHistory(prev => prev.filter(item => item.id !== deleteEntry.id));
      setDeleteEntry(null);
    } catch (error) {
      console.error("Failed to delete workout entry:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredHistory = history.filter(item => {
    if (filter === 'All') return true;
    const itemDate = new Date(item.date);
    const today = new Date();
    
    if (filter === 'Today') {
      return itemDate.toDateString() === today.toDateString();
    }
    if (filter === 'Week') {
      const weekAgo = new Date();
      weekAgo.setDate(today.getDate() - 7);
      return itemDate >= weekAgo;
    }
    if (filter === 'Month') {
      return itemDate.getMonth() === today.getMonth() && itemDate.getFullYear() === today.getFullYear();
    }
    return true;
  });

  // Calculate streak
  const calculateStreak = () => {
    if (!history.length) return 0;
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Create a set of unique dates (midnight)
    const dates = Array.from(new Set(history.map(h => {
      const d = new Date(h.date);
      d.setHours(0, 0, 0, 0);
      return d.getTime();
    }))).sort((a: number, b: number) => b - a);

    let currentDate = today.getTime();
    
    // Check if today is in the set, if not, check if yesterday is (streak might still be active)
    if (dates[0] === currentDate) {
      streak = 1;
      currentDate -= 86400000;
      for (let i = 1; i < dates.length; i++) {
        if (dates[i] === currentDate) {
          streak++;
          currentDate -= 86400000;
        } else {
          break;
        }
      }
    } else if (dates[0] === currentDate - 86400000) {
      currentDate -= 86400000;
      for (let i = 0; i < dates.length; i++) {
        if (dates[i] === currentDate) {
          streak++;
          currentDate -= 86400000;
        } else {
          break;
        }
      }
    }
    
    return streak;
  };

  const streak = calculateStreak();

  return (
    <MainLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)}
            className="h-10 w-10 rounded-xl bg-surface border border-surface-light flex items-center justify-center text-white hover:bg-surface-light transition-colors"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-bold tracking-tight">Workout History</h1>
        </div>

        {/* Streak Card */}
        <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/30 rounded-3xl p-6 flex items-center justify-between shadow-lg shadow-orange-500/5">
          <div>
            <p className="text-orange-500 text-xs font-bold uppercase tracking-widest mb-1">Current Streak</p>
            <h2 className="text-3xl font-bold text-white">{streak} <span className="text-lg text-orange-500/80">days</span> 🔥</h2>
          </div>
          <div className="h-14 w-14 rounded-full bg-orange-500/20 flex items-center justify-center">
            <Flame className="h-7 w-7 text-orange-500" />
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-2 px-2">
          {['All', 'Today', 'Week', 'Month'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={cn(
                "px-5 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition-all",
                filter === f 
                  ? "bg-primary text-black shadow-lg shadow-primary/20" 
                  : "bg-surface border border-surface-light text-text-muted hover:text-white"
              )}
            >
              {f === 'All' ? 'All Workouts' : f === 'Week' ? 'This Week' : f === 'Month' ? 'This Month' : f}
            </button>
          ))}
        </div>

        {/* History List */}
        <div className="space-y-4 pb-10">
          {loading ? (
            <div className="text-center py-10 text-text-muted font-medium">Loading history...</div>
          ) : filteredHistory.length === 0 ? (
            <div className="bg-surface border border-surface-light rounded-3xl p-10 text-center flex flex-col items-center shadow-sm">
              <div className="h-16 w-16 rounded-full bg-surface-light flex items-center justify-center mb-4">
                <Dumbbell className="h-8 w-8 text-text-muted" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">No workouts completed yet</h3>
              <p className="text-sm text-text-muted mb-6">Start your first workout today to build your history.</p>
              <button 
                onClick={() => navigate('/workout')}
                className="bg-primary text-black px-6 py-3 rounded-xl font-bold text-sm hover:bg-primary/90 transition-colors"
              >
                Go to Workout
              </button>
            </div>
          ) : (
            filteredHistory.map((workout) => (
              <div key={workout.id} className="bg-surface border border-surface-light rounded-3xl p-5 shadow-sm group">
                <div className="flex justify-between items-start mb-5">
                  <div>
                    <h3 className="font-bold text-lg text-white mb-1">{workout.title}</h3>
                    <p className="text-xs text-text-muted font-medium">
                      Completed on: {new Date(workout.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => setDeleteEntry({ id: workout.id, title: workout.title })}
                      className="p-2 text-text-muted hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                    <div className="flex items-center gap-1 text-green-500 bg-green-500/10 px-2.5 py-1 rounded-lg border border-green-500/20">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span className="text-[10px] font-bold uppercase tracking-wider">{workout.status}</span>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-surface-light/50 rounded-2xl p-3 flex flex-col items-center justify-center text-center">
                    <Clock className="h-4 w-4 text-primary mb-1.5" />
                    <span className="text-sm font-bold text-white">{workout.duration}</span>
                    <span className="text-[9px] text-text-muted uppercase tracking-widest font-bold mt-0.5">Duration</span>
                  </div>
                  <div className="bg-surface-light/50 rounded-2xl p-3 flex flex-col items-center justify-center text-center">
                    <Flame className="h-4 w-4 text-orange-500 mb-1.5" />
                    <span className="text-sm font-bold text-white">{workout.calories}</span>
                    <span className="text-[9px] text-text-muted uppercase tracking-widest font-bold mt-0.5">Kcal</span>
                  </div>
                  <div className="bg-surface-light/50 rounded-2xl p-3 flex flex-col items-center justify-center text-center">
                    <Dumbbell className="h-4 w-4 text-blue-500 mb-1.5" />
                    <span className="text-sm font-bold text-white">{workout.exercises}</span>
                    <span className="text-[9px] text-text-muted uppercase tracking-widest font-bold mt-0.5">Exercises</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

      </div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteEntry}
        onClose={() => !isDeleting && setDeleteEntry(null)}
        title="Delete Workout Entry"
      >
        <div className="space-y-4">
          <p className="text-text-muted">
            Are you sure you want to delete <span className="text-white font-bold">"{deleteEntry?.title}"</span> from your history?
          </p>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={() => setDeleteEntry(null)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button 
              className="flex-1 bg-red-500 hover:bg-red-600 text-white border-none" 
              onClick={handleDelete}
              isLoading={isDeleting}
            >
              Delete
            </Button>
          </div>
        </div>
      </Modal>
    </MainLayout>
  );
}
