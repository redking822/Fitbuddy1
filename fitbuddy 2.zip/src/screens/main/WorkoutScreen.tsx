import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Calendar, Settings, Sparkles, Clock, Flame, Map, Dumbbell, Play, Utensils, Loader2, CheckCircle2, History, Check } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { handleFirestoreError, OperationType } from '@/lib/firestoreUtils';
import { useApp, WorkoutExercise } from '@/context/AppContext';
import { generateWorkoutPlan } from '@/screens/onboarding/services/aiService';
import { motion, AnimatePresence } from 'motion/react';

export default function WorkoutScreen() {
  const navigate = useNavigate();
  const { user, updateUser, isOffline } = useApp();
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const completedExercises = user?.dailyStats?.completedExercises || [];

  const toggleExercise = (name: string) => {
    if (!user) return;
    
    const isCurrentlyCompleted = completedExercises.includes(name);
    if (isCurrentlyCompleted) return; // No rollback after completion as per requirements

    const newCompleted = [...completedExercises, name];
    
    updateUser({
      dailyStats: {
        ...user.dailyStats,
        completedExercises: newCompleted,
        workouts: user.dailyStats.workouts // Don't increment full workout count yet
      }
    });

    // Optional: Log individual exercise completion to a separate history if needed
    // For now, we follow the requirement: "Reflected in progress stats"
  };

  const handleGeneratePlan = async () => {
    if (!user || isGenerating) return;
    setIsGenerating(true);
    try {
      if (isOffline) {
        throw new Error("Internet connection required to generate new plan.");
      }
      const plan = await generateWorkoutPlan(user);
      updateUser({ 
        workoutPlan: plan,
        dailyStats: {
          ...user.dailyStats,
          completedExercises: [] // Reset for new plan
        }
      });
    } catch (error: any) {
      console.error("Failed to generate workout plan:", error);
      setError(error.message || "Failed to generate workout plan");
    } finally {
      setIsGenerating(false);
    }
  };

  // Auto-generate on first visit if missing
  useEffect(() => {
    if (user && !user.workoutPlan && !isGenerating) {
      handleGeneratePlan();
    }
  }, [user?.workoutPlan]);

  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  const todayStr = today.toISOString().split('T')[0];
  const todayName = today.toLocaleDateString('en-US', { weekday: 'long' });
  const [selectedDay, setSelectedDay] = useState<string>(todayName);

  const currentDayWorkout = user?.workoutPlan?.days?.find(d => d.day === selectedDay) || user?.workoutPlan?.days?.[0];

  const isCompleted = user?.completedWorkouts?.some(w => {
    if (typeof w === 'string') return w === todayStr;
    return w.dayId === user.dailyStats.dayId && w.title === currentDayWorkout?.title;
  });

  const handleComplete = async () => {
    if (!user || !currentDayWorkout) return;
    const currentCompleted = user.completedWorkouts || [];
    if (!isCompleted) {
      const newWorkout = {
        dayId: user.dailyStats.dayId,
        date: todayStr,
        title: currentDayWorkout.title || 'Daily Workout',
        duration: currentDayWorkout.duration || '30 Min',
        status: 'Completed' as const
      };

      // Instant UI Update
      updateUser({ 
        completedWorkouts: [...currentCompleted, newWorkout],
        dailyStats: {
          ...user.dailyStats,
          workouts: user.dailyStats.workouts + 1,
          isDayComplete: true
        }
      });

      // Save to workout_history collection in background
      if (auth.currentUser) {
        const historyPath = `workout_history/${auth.currentUser.uid}/workouts`;
        try {
          const historyRef = collection(db, 'workout_history', auth.currentUser.uid, 'workouts');
          const exercisesCount = (currentDayWorkout.warmup?.length || 0) + 
                                 (currentDayWorkout.mainExercises?.length || 0) + 
                                 (currentDayWorkout.cooldown?.length || 0);
          
          await addDoc(historyRef, {
            userId: auth.currentUser.uid,
            title: newWorkout.title,
            date: new Date().toISOString(),
            duration: newWorkout.duration,
            calories: exercisesCount > 0 ? exercisesCount * 45 : 280,
            exercises: exercisesCount > 0 ? exercisesCount : 8,
            status: 'Completed'
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, historyPath);
        }
      }
    }
  };

  const WorkoutSection = ({ title, exercises }: { title: string, exercises: WorkoutExercise[] }) => {
    if (exercises.length === 0) return null;

    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3 px-2">
          <div className="h-1.5 w-10 bg-primary rounded-full" />
          <h4 className="text-xs font-bold text-primary uppercase tracking-[0.2em]">{title}</h4>
        </div>
        <div className="space-y-6">
          {exercises.map((ex, i) => {
            const isExCompleted = completedExercises.includes(ex.name);
            return (
            <div 
              key={i} 
              className={cn(
                "bg-surface border p-8 rounded-[2.5rem] flex flex-col gap-6 shadow-2xl transition-all active:scale-[0.98]",
                isExCompleted ? "border-primary/50 bg-primary/5" : "border-surface-light"
              )}
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h5 className={cn("font-bold text-2xl leading-tight mb-3", isExCompleted ? "text-primary line-through opacity-70" : "text-white")}>
                    {ex.name}
                  </h5>
                  <div className="flex flex-wrap items-center gap-3 mb-4">
                    <span className="text-sm text-text-muted font-bold bg-surface-light px-4 py-1.5 rounded-xl border border-surface-light">{ex.sets} sets × {ex.reps}</span>
                    <span className="text-sm text-primary font-bold bg-primary/10 px-4 py-1.5 rounded-xl border border-primary/20">{ex.restTime} rest</span>
                  </div>
                  {ex.instruction && (
                    <p className="text-sm text-text-muted leading-relaxed mb-4 bg-surface-light/20 p-4 rounded-2xl border border-surface-light/50">
                      {ex.instruction}
                    </p>
                  )}
                </div>
                <a 
                  href={ex.tutorialUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="h-14 w-14 rounded-2xl bg-surface-light flex flex-col items-center justify-center text-primary hover:bg-primary hover:text-black transition-all shadow-lg shrink-0 ml-4"
                >
                  <Play className="h-6 w-6 fill-current" />
                  <span className="text-[8px] font-bold uppercase mt-1">Watch</span>
                </a>
              </div>

              <div className="h-px w-full bg-surface-light" />

              <motion.button 
                whileTap={{ scale: 0.95 }}
                onClick={() => toggleExercise(ex.name)}
                className={cn(
                  "w-full h-16 rounded-2xl font-bold flex items-center justify-between px-6 transition-all overflow-hidden relative group",
                  isExCompleted 
                    ? "bg-primary text-black shadow-[0_0_20px_rgba(0,255,0,0.2)]" 
                    : "bg-surface-light text-white border border-surface-light hover:border-primary/50"
                )}
              >
                <span className="relative z-10 text-lg">
                  {isExCompleted ? "Completed" : "Mark Complete"}
                </span>
                
                <div className="relative z-10">
                  <AnimatePresence mode="wait">
                    {isExCompleted ? (
                      <motion.div
                        key="checked"
                        initial={{ scale: 0, rotate: -45 }}
                        animate={{ scale: 1, rotate: 0 }}
                        exit={{ scale: 0, rotate: 45 }}
                        className="h-8 w-8 rounded-full bg-black flex items-center justify-center"
                      >
                        <Check className="h-5 w-5 text-primary stroke-[3px]" />
                      </motion.div>
                    ) : (
                      <motion.div
                        key="unchecked"
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        exit={{ scale: 0 }}
                        className="h-8 w-8 rounded-full border-2 border-white/20 flex items-center justify-center"
                      >
                        <div className="h-2 w-2 rounded-full bg-white/20" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {isExCompleted && (
                  <motion.div 
                    initial={{ x: '-100%' }}
                    animate={{ x: '100%' }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
                  />
                )}
              </motion.button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

  return (
    <MainLayout>
      <div className="p-6 space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-surface border border-surface-light flex items-center justify-center text-primary shadow-lg">
              <Calendar className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">{selectedDay === todayName ? "Today's Plan" : `${selectedDay}'s Plan`}</h1>
              <p className="text-[10px] text-primary font-bold uppercase tracking-widest">{formattedDate}</p>
            </div>
          </div>
          <button 
            onClick={() => navigate('/history')}
            className="h-12 w-12 rounded-2xl bg-surface border border-surface-light flex items-center justify-center text-text-muted hover:text-white transition-colors"
          >
            <History className="h-5 w-5" />
          </button>
        </div>

        {/* AI Insights */}
        <div className="bg-surface border border-surface-light rounded-[2rem] p-6 relative overflow-hidden shadow-xl shadow-primary/5">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4 text-primary" />
            <h3 className="text-[10px] font-bold text-primary uppercase tracking-[0.2em]">AI INSIGHTS</h3>
          </div>
          <p className="text-sm text-text-muted leading-relaxed font-medium">
            {currentDayWorkout 
              ? currentDayWorkout.motivationalMessage || `Your personalized ${currentDayWorkout.title} is ready. Focus on ${user?.fitnessLevel} level movements for optimal results.`
              : "Ready to start? Generate your personalized AI workout plan based on your home-use preference."}
          </p>
        </div>

        {!user?.workoutPlan ? (
          <div className="flex flex-col items-center justify-center py-12 text-center space-y-6">
            <div className="h-24 w-24 rounded-[2rem] bg-surface-light flex items-center justify-center text-primary shadow-inner">
              <Dumbbell className="h-10 w-10" />
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2 tracking-tight">No Active Workout</h2>
              <p className="text-sm text-text-muted max-w-xs font-medium">
                We'll create a 7-day home-based workout plan tailored to your {user?.goal} goal and {user?.fitnessLevel} level.
              </p>
            </div>
            <Button 
              className="w-full h-14 rounded-2xl text-lg font-bold shadow-lg shadow-primary/20" 
              onClick={handleGeneratePlan}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Creating Workout...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Generate AI Workout
                </>
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Day Selector */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                <button 
                  key={day} 
                  onClick={() => setSelectedDay(day)} 
                  className={cn(
                    "px-5 py-2.5 rounded-2xl font-bold whitespace-nowrap transition-all", 
                    selectedDay === day 
                      ? "bg-primary text-black shadow-lg shadow-primary/20" 
                      : "bg-surface-light text-text-muted hover:text-white"
                  )}
                >
                  {day.slice(0, 3)}
                </button>
              ))}
            </div>

            <div className="bg-surface border border-surface-light rounded-[2.5rem] p-8 shadow-2xl shadow-primary/5">
              <div className="flex justify-between items-start mb-8">
                  <div>
                    <span className="text-[10px] text-primary font-bold uppercase tracking-widest block mb-2">{currentDayWorkout?.duration}</span>
                    <h3 className="text-2xl font-bold tracking-tight">{currentDayWorkout?.title}</h3>
                    <p className="text-xs text-text-muted font-medium mt-1">Home Workout Focus</p>
                  </div>
                  <div className="h-14 w-14 rounded-2xl bg-surface-light flex items-center justify-center text-primary shadow-inner">
                    <Dumbbell className="h-7 w-7" />
                  </div>
                </div>

                <div className="space-y-8 mb-8">
                  <WorkoutSection title="Warmup" exercises={currentDayWorkout?.warmup || []} />
                  <WorkoutSection title="Main Exercises" exercises={currentDayWorkout?.mainExercises || []} />
                  <WorkoutSection title="Cooldown" exercises={currentDayWorkout?.cooldown || []} />
                </div>

                <div className="flex flex-col gap-3">
                  {isCompleted ? (
                    <div className="flex flex-col items-center justify-center gap-3 py-6 bg-primary/10 rounded-3xl border border-primary/20">
                      <CheckCircle2 className="h-10 w-10 text-primary" />
                      <span className="text-lg font-bold text-primary">Workout Completed!</span>
                      <p className="text-xs text-text-muted">Great job on finishing today's session.</p>
                    </div>
                  ) : (
                    <Button 
                      className="w-full h-16 bg-primary hover:bg-primary/90 text-black font-bold rounded-2xl shadow-lg shadow-primary/20 text-xl"
                      onClick={handleComplete}
                    >
                      <CheckCircle2 className="h-6 w-6 mr-3" /> FINISH WORKOUT
                    </Button>
                  )}
                </div>
              </div>
              
              <Button 
                className="w-full h-14 bg-green-500 hover:bg-green-600 text-white font-bold rounded-2xl shadow-lg shadow-green-500/20"
              onClick={handleGeneratePlan}
              disabled={isGenerating}
            >
              {isGenerating ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : <Sparkles className="h-5 w-5 mr-2" />}
              Regenerate 7-Day Plan
            </Button>
          </div>
        )}

      </div>
      <Modal isOpen={!!error} onClose={() => setError(null)} title="Error">
        <div className="text-center space-y-4">
          <p className="text-text-muted">{error}</p>
          <Button onClick={() => setError(null)} className="w-full bg-primary text-black hover:bg-primary/90">
            Close
          </Button>
        </div>
      </Modal>
    </MainLayout>
  );
}
