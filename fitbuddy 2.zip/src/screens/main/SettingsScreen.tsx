import { MobileLayout } from '@/components/layout/MobileLayout';
import { ChevronLeft, User, Bell, Lock, HelpCircle, LogOut, ChevronRight, Moon } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { auth } from '@/lib/firebase';
import { signOut } from 'firebase/auth';

export default function SettingsScreen() {
  const navigate = useNavigate();
  const { user } = useApp();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      localStorage.clear();
      navigate('/');
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  const SettingItem = ({ icon: Icon, label, value }: { icon: React.ElementType, label: string, value?: string }) => (
    <button className="w-full flex items-center justify-between p-4 border-b border-surface-light hover:bg-surface-light/50 transition-colors">
      <div className="flex items-center gap-3">
        <Icon className="h-5 w-5 text-text-muted" />
        <span className="font-medium text-sm">{label}</span>
      </div>
      <div className="flex items-center gap-2">
        {value && <span className="text-xs text-text-muted">{value}</span>}
        <ChevronRight className="h-4 w-4 text-text-muted" />
      </div>
    </button>
  );

  return (
    <MobileLayout>
      <div className="flex items-center justify-between p-4 border-b border-surface-light">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-lg font-bold">Settings</h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 flex flex-col items-center border-b border-surface-light">
          <div className="h-20 w-20 rounded-full bg-surface-light mb-3 overflow-hidden">
            <img src={user?.profileImage || "https://picsum.photos/seed/user/100/100"} alt="User" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <h2 className="font-bold text-lg">{user?.name}</h2>
          <p className="text-xs text-text-muted">{user?.email || 'user@example.com'}</p>
          <Button variant="outline" size="sm" className="mt-4 border-primary text-primary hover:bg-primary hover:text-black">
            Edit Profile
          </Button>
        </div>

        <div className="mt-4">
          <h3 className="px-4 py-2 text-xs font-bold text-text-muted uppercase">ACCOUNT</h3>
          <SettingItem icon={User} label="Personal Details" />
          <SettingItem icon={Lock} label="Privacy & Security" />
          <SettingItem icon={Bell} label="Notifications" value="On" />
        </div>

        <div className="mt-4">
          <h3 className="px-4 py-2 text-xs font-bold text-text-muted uppercase">APP SETTINGS</h3>
          <SettingItem icon={Moon} label="Dark Mode" value="System" />
          <SettingItem icon={HelpCircle} label="Help & Support" />
        </div>

        <div className="p-6 mt-4">
          <Button 
            variant="ghost" 
            className="w-full text-red-500 hover:bg-red-500/10 hover:text-red-600 justify-start px-4"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 mr-3" />
            Log Out
          </Button>
          <p className="text-center text-[10px] text-text-muted mt-6">
            FitBuddy v1.0.0 (Build 2026.03.21)
          </p>
        </div>
      </div>
    </MobileLayout>
  );
}
