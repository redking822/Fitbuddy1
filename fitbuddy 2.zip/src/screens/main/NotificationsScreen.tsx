import { MobileLayout } from '@/components/layout/MobileLayout';
import { ChevronLeft, Bell, Clock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useNavigate } from 'react-router-dom';

export default function NotificationsScreen() {
  const navigate = useNavigate();

  const NotificationItem = ({ title, desc, time, icon: Icon, isNew }: { title: string, desc: string, time: string, icon: any, isNew?: boolean }) => (
    <div className={`p-4 border-b border-surface-light flex gap-4 ${isNew ? 'bg-surface-light/30' : ''}`}>
      <div className="h-10 w-10 rounded-full bg-surface-light flex items-center justify-center text-primary shrink-0">
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-bold text-sm">{title}</h3>
          <span className="text-[10px] text-text-muted">{time}</span>
        </div>
        <p className="text-xs text-text-muted leading-relaxed">{desc}</p>
      </div>
      {isNew && <div className="h-2 w-2 rounded-full bg-primary mt-2" />}
    </div>
  );

  return (
    <MobileLayout>
      <div className="flex items-center justify-between p-4 border-b border-surface-light">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-lg font-bold">Notifications</h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="p-4 pb-2">
          <h2 className="text-xs font-bold text-text-muted uppercase">TODAY</h2>
        </div>
        <NotificationItem 
          title="Time to Workout!" 
          desc="Your scheduled 'Evening Strength' session starts in 15 minutes." 
          time="5:45 PM" 
          icon={Clock}
          isNew
        />
        <NotificationItem 
          title="Hydration Reminder" 
          desc="You haven't logged water in 3 hours. Drink a glass now!" 
          time="2:30 PM" 
          icon={Bell}
          isNew
        />

        <div className="p-4 pb-2 mt-4">
          <h2 className="text-xs font-bold text-text-muted uppercase">YESTERDAY</h2>
        </div>
        <NotificationItem 
          title="Goal Achieved" 
          desc="Congratulations! You hit your daily step goal of 10,000 steps." 
          time="8:00 PM" 
          icon={Calendar}
        />
        <NotificationItem 
          title="New Diet Plan" 
          desc="Your AI coach has updated your meal plan for the week." 
          time="9:00 AM" 
          icon={Calendar}
        />
      </div>
    </MobileLayout>
  );
}
