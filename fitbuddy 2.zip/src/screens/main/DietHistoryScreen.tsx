import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { auth } from '@/lib/firebase';
import { History, UtensilsCrossed, Flame, CheckCircle2, ArrowLeft, Loader2, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { getDietHistory, deleteDietEntry, DietHistoryEntry } from '@/screens/onboarding/services/historyService';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { useApp } from '@/context/AppContext';

export default function DietHistoryScreen() {
  const navigate = useNavigate();
  const { user } = useApp();
  const [history, setHistory] = useState<DietHistoryEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteEntry, setDeleteEntry] = useState<{id: string, name: string} | null>(null);

  const fetchHistory = async () => {
    if (!auth.currentUser) return;
    setIsLoading(true);
    const data = await getDietHistory(auth.currentUser.uid);
    setHistory(data);
    setIsLoading(false);
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleDelete = async () => {
    if (!auth.currentUser || !deleteEntry) return;
    
    setIsDeleting(true);
    try {
      await deleteDietEntry(auth.currentUser.uid, deleteEntry.id);
      setHistory(prev => prev.filter(item => item.id !== deleteEntry.id));
      setDeleteEntry(null);
    } catch (error) {
      console.error("Failed to delete entry:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  // Group meals by date
  const historyByDate = history.reduce((acc, entry) => {
    const date = entry.completedAt ? new Date(entry.completedAt.seconds * 1000).toISOString().split('T')[0] : new Date().toISOString().split('T')[0];
    if (!acc[date]) {
      acc[date] = {
        date,
        totalCalories: 0,
        totalProtein: 0,
        meals: []
      };
    }
    acc[date].totalCalories += entry.calories;
    acc[date].totalProtein += (entry.protein || 0);
    acc[date].meals.push(entry);
    return acc;
  }, {} as Record<string, { date: string, totalCalories: number, totalProtein: number, meals: DietHistoryEntry[] }>);

  // Sort dates descending
  const sortedDates = Object.keys(historyByDate).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  return (
    <MainLayout>
      <div className="p-6 space-y-8">
        
        {/* Header */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)}
            className="h-12 w-12 rounded-2xl bg-surface border border-surface-light flex items-center justify-center text-text-muted hover:text-white transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="h-12 w-12 rounded-2xl bg-surface border border-surface-light flex items-center justify-center text-primary shadow-lg">
            <History className="h-6 w-6" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">Diet History</h1>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 text-primary animate-spin" />
          </div>
        ) : sortedDates.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
            <div className="h-20 w-20 rounded-full bg-surface-light flex items-center justify-center text-text-muted">
              <UtensilsCrossed className="h-10 w-10" />
            </div>
            <h2 className="text-xl font-bold">No Meals Logged</h2>
            <p className="text-sm text-text-muted max-w-xs">
              Your logged meals will appear here. Start logging your meals from the Diet screen.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {sortedDates.map(date => {
              const dayData = historyByDate[date];
              const dateObj = new Date(date);
              const formattedDate = dateObj.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
              
              return (
                <div key={date} className="bg-surface border border-surface-light rounded-3xl p-6 shadow-xl shadow-primary/5">
                  <div className="flex justify-between items-end mb-6 border-b border-surface-light pb-4">
                    <div>
                      <p className="text-xs font-bold text-primary uppercase tracking-widest mb-1">Date</p>
                      <h3 className="text-xl font-bold">{formattedDate}</h3>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-text-muted uppercase tracking-widest mb-1">Total</p>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1 text-orange-500">
                          <Flame className="h-4 w-4" />
                          <span className="font-bold">{dayData.totalCalories} kcal</span>
                        </div>
                        <div className="flex items-center gap-1 text-primary">
                          <CheckCircle2 className="h-4 w-4" />
                          <span className="font-bold">{dayData.totalProtein}g</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {dayData.meals.map((meal, idx) => (
                      <div key={idx} className="bg-surface-light/30 rounded-2xl p-4 flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                          <div className="h-10 w-10 rounded-xl bg-surface border border-surface-light flex items-center justify-center text-primary">
                            <UtensilsCrossed className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-bold text-sm">{meal.mealName}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <p className="text-sm font-bold text-orange-500">{meal.calories} kcal</p>
                            {meal.protein && <p className="text-xs font-medium text-primary">{meal.protein}g protein</p>}
                          </div>
                          <button 
                            onClick={() => setDeleteEntry({ id: meal.id, name: meal.mealName })}
                            className="p-2 text-text-muted hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteEntry}
        onClose={() => !isDeleting && setDeleteEntry(null)}
        title="Delete Meal Entry"
      >
        <div className="space-y-4">
          <p className="text-text-muted">
            Are you sure you want to delete <span className="text-white font-bold">"{deleteEntry?.name}"</span> from your history?
          </p>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={() => setDeleteEntry(null)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button 
              className="flex-1 bg-red-500 hover:bg-red-600 text-white border-none" 
              onClick={handleDelete}
              isLoading={isDeleting}
            >
              Delete
            </Button>
          </div>
        </div>
      </Modal>
    </MainLayout>
  );
}
