import { MainLayout } from '@/components/layout/MainLayout';
import { Bell, ChevronLeft, ChevronRight, Lock, Trophy, Footprints, CheckCircle2, Ruler, Weight, Dumbbell, Calendar, Clock, Plus } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { cn } from '@/lib/utils';
import { useApp } from '@/context/AppContext';
import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

export default function ProgressScreen() {
  const { user, updateUser } = useApp();
  const navigate = useNavigate();
  const [isLoggingWeight, setIsLoggingWeight] = useState(false);
  const [newWeight, setNewWeight] = useState(user?.weight?.toString() || '');
  
  const weightData = useMemo(() => {
    if (user?.weightHistory && user.weightHistory.length >= 2) {
      return user.weightHistory.slice(-7).map(entry => ({
        name: new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        weight: entry.weight,
        fullDate: entry.date
      }));
    }
    
    // Generate mock data if none exists
    const mockData = [];
    const baseWeight = user?.weight || 70;
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - (i * 4));
      mockData.push({
        name: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        weight: Number((baseWeight - (i * 0.3) + (Math.random() * 0.2)).toFixed(1)),
        fullDate: d.toISOString().split('T')[0]
      });
    }
    return mockData;
  }, [user?.weightHistory, user?.weight]);

  const handleLogWeight = () => {
    const weightNum = parseFloat(newWeight);
    if (isNaN(weightNum)) return;

    const today = new Date().toISOString().split('T')[0];
    const newEntry = { date: today, weight: weightNum };
    
    const currentHistory = user?.weightHistory || [];
    // Update or add today's entry
    const existingIndex = currentHistory.findIndex(e => e.date === today);
    let updatedHistory;
    if (existingIndex >= 0) {
      updatedHistory = [...currentHistory];
      updatedHistory[existingIndex] = newEntry;
    } else {
      updatedHistory = [...currentHistory, newEntry];
    }

    updateUser({
      weight: weightNum,
      weightHistory: updatedHistory
    });
    setIsLoggingWeight(false);
  };

  const today = new Date();
  const currentMonth = today.toLocaleString('default', { month: 'long' });
  const currentYear = today.getFullYear();

  // Helper to get days in month
  const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const daysInMonth = getDaysInMonth(currentYear, today.getMonth());
  const firstDayOfMonth = new Date(currentYear, today.getMonth(), 1).getDay();
  // Adjust firstDayOfMonth to start from Monday (0=Mon, 6=Sun)
  const startOffset = (firstDayOfMonth + 6) % 7;

  // Format history data
  const historyData = [...(user?.completedWorkouts || [])].reverse().map(w => {
    if (typeof w === 'string') {
      return {
        date: w,
        title: 'Daily Workout',
        duration: '30 Min',
        status: 'Completed'
      };
    }
    return w;
  });

  return (
    <MainLayout>
      <div className="p-6 space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-surface-light border border-surface-light p-0.5 overflow-hidden shadow-inner">
              <img src={user?.profileImage || "https://picsum.photos/seed/user/100/100"} alt="User" className="rounded-xl w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">Progress & Stats</h1>
          </div>
          <button className="h-12 w-12 rounded-2xl bg-surface border border-surface-light flex items-center justify-center text-white hover:bg-surface-light transition-all active:scale-95">
            <Bell className="h-5 w-5" />
          </button>
        </div>

        {/* Weekly Overview */}
        <div className="bg-surface border border-surface-light rounded-[2.5rem] p-8 relative overflow-hidden shadow-2xl shadow-primary/5">
          <div className="flex justify-between items-start mb-8">
            <div>
              <p className="text-[10px] text-primary font-bold uppercase tracking-widest mb-1">Weekly Calories</p>
              <h2 className="text-4xl font-bold tracking-tight">{(user?.dailyStats?.calories || 0) * 7} <span className="text-sm font-medium text-text-muted">kcal</span></h2>
            </div>
            <span className="bg-green-500/10 text-green-500 text-[10px] font-bold px-3 py-1 rounded-full border border-green-500/20">+5.2%</span>
          </div>
          
          <div className="flex justify-between items-end h-32 gap-3">
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => {
              const heights = [40, 60, 30, 80, 50, 90, 70];
              const height = heights[i];
              // Correct weekday mapping (0=Sun, 1=Mon, ..., 6=Sat)
              const dayIndex = today.getDay();
              const adjustedDayIndex = (dayIndex + 6) % 7; // 0=Mon, ..., 6=Sun
              const isToday = adjustedDayIndex === i;
              
              return (
                <div key={i} className="flex flex-col items-center gap-3 flex-1">
                  <div 
                    className={cn(
                      "w-full rounded-full transition-all duration-500",
                      isToday ? "bg-primary shadow-lg shadow-primary/30" : "bg-surface-light/50"
                    )}
                    style={{ height: `${height}%` }}
                  />
                  <span className={cn(
                    "text-[10px] font-bold tracking-tighter",
                    isToday ? "text-primary" : "text-text-muted"
                  )}>{day}</span>
                </div>
              )
            })}
          </div>
        </div>

        {/* Weight Trend */}
        <div className="bg-surface border border-surface-light rounded-[2.5rem] p-8 shadow-2xl shadow-primary/5">
          <div className="flex justify-between items-start mb-6">
            <div>
              <p className="text-[10px] text-primary font-bold uppercase tracking-widest mb-1">Weight Trend</p>
              <div className="flex items-baseline gap-2">
                <h2 className="text-4xl font-bold tracking-tight">{user?.weight || '--'}</h2>
                <span className="text-sm font-medium text-text-muted">kg</span>
              </div>
            </div>
            <button 
              onClick={() => setIsLoggingWeight(true)}
              className="h-10 w-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary hover:bg-primary hover:text-black transition-all active:scale-95"
            >
              <Plus className="h-5 w-5" />
            </button>
          </div>

          <div className="h-56 w-full -mx-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weightData}>
                <defs>
                  <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00ff66" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00ff66" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#666', fontSize: 10, fontWeight: 'bold' }}
                  dy={10}
                />
                <YAxis 
                  hide 
                  domain={['dataMin - 2', 'dataMax + 2']} 
                />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-surface-light border border-white/10 p-3 rounded-2xl shadow-xl backdrop-blur-md">
                          <p className="text-[10px] text-text-muted font-bold uppercase tracking-widest mb-1">{payload[0].payload.name}</p>
                          <p className="text-lg font-bold text-primary">{payload[0].value} <span className="text-[10px] text-white/60">kg</span></p>
                        </div>
                      );
                    }
                    return null;
                  }}
                  cursor={{ stroke: '#00ff66', strokeWidth: 1, strokeDasharray: '4 4' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="weight" 
                  stroke="#00ff66" 
                  strokeWidth={4} 
                  fillOpacity={1} 
                  fill="url(#colorWeight)" 
                  animationDuration={1500}
                  dot={{ r: 4, fill: '#00ff66', strokeWidth: 2, stroke: '#121212' }}
                  activeDot={{ r: 6, fill: '#00ff66', strokeWidth: 2, stroke: '#fff' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          <div className="flex justify-between text-[10px] text-text-muted font-bold uppercase tracking-widest mt-6 px-2">
            <span>Progressive Weight Tracking</span>
            <span className="text-primary">Last 7 Entries</span>
          </div>
        </div>

        {/* Weight Logging Modal */}
        <AnimatePresence>
          {isLoggingWeight && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsLoggingWeight(false)}
                className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="relative w-full max-w-sm bg-surface border border-surface-light rounded-[2.5rem] p-8 shadow-2xl"
              >
                <h3 className="text-2xl font-bold mb-6">Log Weight</h3>
                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] text-text-muted font-bold uppercase tracking-widest mb-2 block">Current Weight (kg)</label>
                    <input 
                      type="number" 
                      step="0.1"
                      value={newWeight}
                      onChange={(e) => setNewWeight(e.target.value)}
                      className="w-full bg-surface-light border border-surface-light rounded-2xl p-4 text-xl font-bold focus:outline-none focus:border-primary transition-colors"
                      placeholder="70.0"
                      autoFocus
                    />
                  </div>
                  <div className="flex gap-3">
                    <button 
                      onClick={() => setIsLoggingWeight(false)}
                      className="flex-1 h-14 rounded-2xl bg-surface-light font-bold hover:bg-surface-light/80 transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleLogWeight}
                      className="flex-1 h-14 rounded-2xl bg-primary text-black font-bold hover:opacity-90 transition-opacity"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Workout Consistency */}
        <div>
          <div className="flex items-center justify-between mb-5 px-2">
            <h2 className="text-xl font-bold tracking-tight">Consistency</h2>
            <div className="flex items-center gap-2 bg-primary/10 px-3 py-1.5 rounded-full border border-primary/20">
              <Trophy className="h-3.5 w-3.5 text-primary" />
              <span className="text-primary text-[11px] font-bold uppercase tracking-wider">{user?.completedWorkouts?.length || 0} Day Streak</span>
            </div>
          </div>

          <div className="bg-surface border border-surface-light rounded-[2.5rem] p-8 shadow-2xl shadow-primary/5">
            <div className="flex items-center justify-between mb-8">
              <h3 className="font-bold text-lg">{currentMonth} {currentYear}</h3>
              <div className="flex gap-2">
                <button className="h-10 w-10 rounded-xl bg-surface-light flex items-center justify-center text-text-muted hover:text-white transition-colors">
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button className="h-10 w-10 rounded-xl bg-surface-light flex items-center justify-center text-white hover:bg-white/80 transition-colors">
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-y-6 text-center">
              {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
                <span key={i} className="text-[10px] font-bold text-text-muted uppercase tracking-widest">{d}</span>
              ))}
              
              {/* Empty slots for start of month */}
              {[...Array(startOffset)].map((_, i) => (
                <div key={`empty-${i}`} className="h-10 w-10" />
              ))}

              {/* Calendar Days */}
              {[...Array(daysInMonth)].map((_, i) => {
                const d = i + 1;
                const dateStr = `${currentYear}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
                const isToday = d === today.getDate();
                const isCompleted = user?.completedWorkouts?.some(w => typeof w === 'string' ? w === dateStr : w.date === dateStr);
                
                return (
                  <div key={d} className="flex items-center justify-center relative">
                    {isCompleted ? (
                      <div className="h-10 w-10 rounded-2xl bg-primary flex items-center justify-center text-black shadow-lg shadow-primary/20 transform hover:scale-110 transition-transform">
                        <CheckCircle2 className="h-6 w-6 fill-current" />
                      </div>
                    ) : (
                      <div className={cn(
                        "h-10 w-10 rounded-2xl flex items-center justify-center text-sm font-bold transition-all border",
                        isToday ? "border-primary text-primary bg-primary/5" : "border-transparent text-white/40 hover:bg-surface-light/30"
                      )}>
                        {d}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div>
          <h2 className="text-lg font-bold mb-4">Achievements</h2>
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            
            <div className="min-w-[140px] bg-surface border border-surface-light rounded-3xl p-4 flex flex-col items-center text-center">
              <div className="h-16 w-16 rounded-full bg-surface-light flex items-center justify-center mb-3">
                <Footprints className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold text-sm">10k Steps</h3>
              <p className="text-[10px] text-text-muted">Daily Goal Met</p>
            </div>

            <div className="min-w-[140px] bg-surface border border-surface-light rounded-3xl p-4 flex flex-col items-center text-center">
              <div className="h-16 w-16 rounded-full bg-surface-light flex items-center justify-center mb-3">
                <Trophy className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold text-sm">First Workout</h3>
              <p className="text-[10px] text-text-muted">Journey Started</p>
            </div>

            <div className="min-w-[140px] bg-surface border border-surface-light rounded-3xl p-4 flex flex-col items-center text-center opacity-50">
              <div className="h-16 w-16 rounded-full bg-surface-light flex items-center justify-center mb-3">
                <Lock className="h-8 w-8 text-text-muted" />
              </div>
              <h3 className="font-bold text-sm">Century</h3>
              <p className="text-[10px] text-text-muted">100 Workouts</p>
            </div>

          </div>
        </div>

        {/* Workout History */}
        <div>
          <div className="flex items-center justify-between mb-4 px-2">
            <h2 className="text-lg font-bold">Workout History</h2>
            <button onClick={() => navigate('/history')} className="text-xs text-primary font-bold uppercase tracking-widest hover:text-white transition-colors">View All</button>
          </div>
          
          <div className="space-y-3">
            {historyData.length === 0 ? (
              <div className="bg-surface border border-surface-light rounded-3xl p-8 text-center">
                <Dumbbell className="h-8 w-8 text-text-muted mx-auto mb-3" />
                <p className="text-sm font-medium text-text-muted">No workouts completed yet.</p>
              </div>
            ) : (
              historyData.map((workout, idx) => (
                <div key={idx} className="bg-surface border border-surface-light rounded-2xl p-4 flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-xl bg-surface-light flex items-center justify-center text-primary">
                      <Dumbbell className="h-6 w-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-base text-white">{workout.title}</h4>
                      <div className="flex items-center gap-3 mt-1">
                        <div className="flex items-center gap-1 text-xs text-text-muted font-medium">
                          <Calendar className="h-3 w-3" />
                          <span>{new Date(workout.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-text-muted font-medium">
                          <Clock className="h-3 w-3" />
                          <span>{workout.duration}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <div className="flex items-center gap-1 text-green-500 bg-green-500/10 px-2 py-1 rounded-lg">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span className="text-[10px] font-bold uppercase tracking-wider">{workout.status}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </MainLayout>
  );
}
