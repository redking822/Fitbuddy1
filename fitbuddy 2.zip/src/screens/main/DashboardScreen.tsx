import { MainLayout } from '@/components/layout/MainLayout';
import { useApp } from '@/context/AppContext';
import { Flame, Droplets, Dumbbell, Play, ChevronRight, Sparkles, Loader2, CheckCircle2, Zap, Plus } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { generateDietPlan, generateWorkoutPlan } from '@/screens/onboarding/services/aiService';

export default function DashboardScreen() {
  const { user, updateUser, updateDailyStats, isOffline } = useApp();
  const stats = user?.dailyStats || { calories: 0, protein: 0, water: 0, workouts: 0, calorieTarget: 2000, proteinTarget: 60, completedExercises: [], isDayComplete: false };

  const todayName = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  const [selectedDay, setSelectedDay] = useState<string>(todayName);

  const selectedDiet = user?.dietPlan?.days?.find(d => d.day === selectedDay) || user?.dietPlan?.days?.[0];
  const selectedWorkout = user?.workoutPlan?.days?.find(d => d.day === selectedDay) || user?.workoutPlan?.days?.[0];

  const calorieGoal = selectedDiet ? (selectedDiet.dailyNutritionSummary.totalCalories || 2000) : (stats.calorieTarget || 2000);
  const proteinGoal = selectedDiet ? (selectedDiet.dailyNutritionSummary.totalProtein || 60) : (stats.proteinTarget || 60);
  const isDietComplete = calorieGoal > 0 && stats.calories >= calorieGoal;
  const isProteinComplete = proteinGoal > 0 && stats.protein >= proteinGoal;

  const totalExercises = (selectedWorkout?.warmup?.length || 0) + 
                        (selectedWorkout?.mainExercises?.length || 0) + 
                        (selectedWorkout?.cooldown?.length || 0) || 0;

  const workoutProgress = stats.completedExercises?.length || 0;

  const [isManualAddModalOpen, setIsManualAddModalOpen] = useState(false);
  const [manualAddType, setManualAddType] = useState<'calories' | 'protein' | 'workout'>('calories');
  const [manualAddValue, setManualAddValue] = useState('');

  // Background Task System - Removed automatic generation to prevent confusion
  useEffect(() => {
    if (!user) return;

    const runBackgroundTasks = async () => {
      // We only log here, no more automatic background generation that updates stats
      console.log("Dashboard loaded. User has plan:", !!user.dietPlan);
    };

    runBackgroundTasks();
  }, [user?.workoutPlan, user?.dietPlan]);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return "Good Morning";
    if (hour >= 12 && hour < 17) return "Good Afternoon";
    if (hour >= 17 && hour < 21) return "Good Evening";
    return "Good Night";
  };

  const handleAddWater = () => {
    updateDailyStats({ water: stats.water + 1 });
  };

  const openManualAdd = (type: 'calories' | 'protein' | 'workout') => {
    setManualAddType(type);
    setManualAddValue('');
    setIsManualAddModalOpen(true);
  };

  const handleManualAddSubmit = () => {
    const value = parseInt(manualAddValue);
    if (isNaN(value) || value <= 0) return;

    if (manualAddType === 'calories') {
      updateDailyStats({ calories: stats.calories + value });
    } else if (manualAddType === 'protein') {
      updateDailyStats({ protein: stats.protein + value });
    } else if (manualAddType === 'workout') {
      updateDailyStats({ workouts: stats.workouts + value });
    }
    
    setIsManualAddModalOpen(false);
  };

  return (
    <MainLayout>
      <div className="p-6 space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-2xl bg-surface-light border border-surface-light p-0.5 overflow-hidden shadow-inner">
               <img src={user?.profileImage || "https://picsum.photos/seed/user/100/100"} alt="User" className="rounded-xl w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div>
              <p className="text-[10px] text-primary font-bold uppercase tracking-[0.2em] mb-1">
                {isOffline ? <span className="text-orange-500">Offline Mode</span> : "Dashboard"}
              </p>
              <h1 className="text-xl font-bold tracking-tight">{getGreeting()}, {user?.name?.split(' ')[0] || 'Alex'}</h1>
            </div>
          </div>
          {isOffline && (
            <div className="h-10 w-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500">
              <Zap className="h-5 w-5" />
            </div>
          )}
        </div>

        {/* Day Selector */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
            <button 
              key={day} 
              onClick={() => setSelectedDay(day)} 
              className={`px-5 py-2.5 rounded-2xl font-bold whitespace-nowrap transition-all ${
                selectedDay === day 
                  ? "bg-primary text-black shadow-lg shadow-primary/20" 
                  : "bg-surface-light text-text-muted hover:text-white"
              }`}
            >
              {day.slice(0, 3)}
            </button>
          ))}
        </div>

        {/* Daily Summary */}
        <div className="space-y-4">
          <h2 className="text-lg font-bold">Daily Summary</h2>
          
          <div className="grid grid-cols-1 gap-4">
            {/* Calories Card */}
            <div className="bg-surface rounded-3xl p-6 flex flex-col items-center justify-center text-center border border-surface-light shadow-sm relative overflow-hidden group">
              {isDietComplete && (
                <div className="absolute top-4 right-4 bg-green-500 text-black text-[10px] font-black px-2 py-1 rounded-full animate-pulse">
                  DONE
                </div>
              )}
              <button 
                onClick={() => openManualAdd('calories')}
                className="absolute top-4 left-4 h-8 w-8 rounded-full bg-surface-light flex items-center justify-center text-text-muted hover:text-white hover:bg-blue-500/20 transition-colors"
              >
                <Plus className="h-4 w-4" />
              </button>
              <div className="relative h-28 w-28 mb-3">
                 <svg className="h-full w-full -rotate-90" viewBox="0 0 36 36">
                   <path className="text-surface-light" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                   <path className="text-blue-500" strokeDasharray={`${calorieGoal > 0 ? Math.min((stats.calories / calorieGoal) * 100, 100) : 0}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                 </svg>
                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                   <Flame className="h-6 w-6 text-blue-500 mb-1" />
                   <span className="text-lg font-bold">{stats.calories}</span>
                 </div>
              </div>
              <p className="text-xs font-bold text-text-muted uppercase tracking-widest">CALORIES</p>
              <p className="text-sm font-bold text-white">
                {calorieGoal > 0 ? `${stats.calories} / ${calorieGoal} kcal` : 'No Plan Generated'}
              </p>
            </div>

            {/* Protein Card */}
            <div className="bg-surface rounded-3xl p-6 flex flex-col items-center justify-center text-center border border-surface-light shadow-sm relative overflow-hidden group">
              {isProteinComplete && (
                <div className="absolute top-4 right-4 bg-primary text-black text-[10px] font-black px-2 py-1 rounded-full animate-pulse">
                  DONE
                </div>
              )}
              <button 
                onClick={() => openManualAdd('protein')}
                className="absolute top-4 left-4 h-8 w-8 rounded-full bg-surface-light flex items-center justify-center text-text-muted hover:text-white hover:bg-primary/20 transition-colors"
              >
                <Plus className="h-4 w-4" />
              </button>
              <div className="relative h-28 w-28 mb-3">
                 <svg className="h-full w-full -rotate-90" viewBox="0 0 36 36">
                   <path className="text-surface-light" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                   <path className="text-primary" strokeDasharray={`${proteinGoal > 0 ? Math.min((stats.protein / proteinGoal) * 100, 100) : 0}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                 </svg>
                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                   <Zap className="h-6 w-6 text-primary mb-1" />
                   <span className="text-lg font-bold">{stats.protein}</span>
                 </div>
              </div>
              <p className="text-xs font-bold text-text-muted uppercase tracking-widest">PROTEIN</p>
              <p className="text-sm font-bold text-white">
                {proteinGoal > 0 ? `${stats.protein} / ${proteinGoal} g` : 'No Plan Generated'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Hydration Card */}
            <div 
              className="bg-surface rounded-3xl p-4 flex flex-col justify-between h-40 border border-surface-light cursor-pointer active:scale-95 transition-transform"
              onClick={handleAddWater}
            >
               <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                 <Droplets className="h-5 w-5 text-blue-500" />
               </div>
               <div>
                 <h3 className="text-lg font-bold">{stats.water} glasses</h3>
                 <p className="text-xs text-text-muted mb-2">Hydration (Tap to add)</p>
                 <div className="flex gap-1 flex-wrap max-h-8 overflow-hidden">
                   {[...Array(Math.min(stats.water, 20))].map((_, i) => <div key={i} className="h-2 w-2 rounded-full bg-blue-500" />)}
                   {stats.water > 20 && <span className="text-[10px] text-blue-500 font-bold">+{stats.water - 20}</span>}
                 </div>
               </div>
            </div>

            {/* Workouts Card */}
            <div className="bg-surface rounded-3xl p-4 flex flex-col justify-between h-40 border border-surface-light">
               <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                 <Dumbbell className="h-5 w-5 text-purple-500" />
               </div>
               <div>
                 <h3 className="text-lg font-bold">
                   {totalExercises > 0 ? `${workoutProgress} of ${totalExercises}` : 'No Plan'}
                 </h3>
                 <p className="text-xs text-text-muted">Exercises completed</p>
               </div>
            </div>
          </div>
        </div>

        {/* Start Workout CTA */}
        <div className="pb-4">
          <Button className="w-full h-14 text-lg font-bold bg-blue-500 hover:bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-500/20" onClick={() => window.location.href = '/workout'}>
            <Play className="fill-current h-5 w-5 mr-3" />
            Start {selectedDay === todayName ? "Today's" : `${selectedDay}'s`} Workout
          </Button>
        </div>
      </div>

      {/* Manual Add Modal */}
      <Modal
        isOpen={isManualAddModalOpen}
        onClose={() => setIsManualAddModalOpen(false)}
        title={`Add ${manualAddType === 'calories' ? 'Calories' : manualAddType === 'protein' ? 'Protein' : 'Workout'}`}
      >
        <div className="space-y-4">
          <p className="text-sm text-text-muted">
            Enter the amount of {manualAddType} to add to your daily total.
          </p>
          <div className="relative">
            <input
              type="number"
              value={manualAddValue}
              onChange={(e) => setManualAddValue(e.target.value)}
              placeholder={`e.g. ${manualAddType === 'calories' ? '300' : manualAddType === 'protein' ? '25' : '1'}`}
              className="w-full bg-surface border border-surface-light rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary"
              autoFocus
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-text-muted text-sm font-bold">
              {manualAddType === 'calories' ? 'kcal' : manualAddType === 'protein' ? 'g' : ''}
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={() => setIsManualAddModalOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              className="flex-1 bg-primary text-black hover:bg-primary/90 border-none" 
              onClick={handleManualAddSubmit}
              disabled={!manualAddValue || parseInt(manualAddValue) <= 0}
            >
              Add
            </Button>
          </div>
        </div>
      </Modal>

    </MainLayout>
  );
}
