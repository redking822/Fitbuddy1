import React, { useRef } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Settings, ChevronRight, LogOut, Bell, Shield, CreditCard, HelpCircle, Camera, User, Ruler, Weight, History, UtensilsCrossed } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { cn } from '@/lib/utils';

import { useNavigate } from 'react-router-dom';

export default function ProfileScreen() {
  const navigate = useNavigate();
  const { user, logout, updateUser } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLogout = async () => {
    await logout();
    window.location.href = '/';
  };

  const handleImageClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 400;
          const MAX_HEIGHT = 400;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          // Compress to JPEG with 0.7 quality to ensure it fits in Firestore
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          updateUser({ profileImage: dataUrl });
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const ProfileStat = ({ label, value, icon: Icon }: { label: string, value: string | number, icon: React.ElementType }) => (
    <div className="bg-surface-light/30 border border-surface-light rounded-2xl p-4 flex flex-col items-center justify-center text-center">
      <Icon className="h-4 w-4 text-primary mb-2" />
      <span className="text-lg font-bold">{value}</span>
      <span className="text-[10px] text-text-muted uppercase font-bold tracking-wider">{label}</span>
    </div>
  );

  const SettingItem = ({ icon: Icon, label, value, color, onClick }: { icon: React.ElementType, label: string, value?: string, color?: string, onClick?: () => void }) => (
    <button 
      onClick={onClick}
      className="w-full flex items-center justify-between p-4 bg-surface border border-surface-light rounded-2xl hover:bg-surface-light/50 transition-colors"
    >
      <div className="flex items-center gap-4">
        <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", color || "bg-surface-light text-text-muted")}>
          <Icon className="h-5 w-5" />
        </div>
        <span className="font-medium">{label}</span>
      </div>
      <div className="flex items-center gap-2">
        {value && <span className="text-sm text-text-muted">{value}</span>}
        <ChevronRight className="h-4 w-4 text-text-muted" />
      </div>
    </button>
  );

  return (
    <MainLayout>
      <div className="p-6 space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold uppercase tracking-widest">Profile</h1>
          <button className="h-10 w-10 rounded-xl bg-surface-light flex items-center justify-center text-text-muted">
            <Settings className="h-5 w-5" />
          </button>
        </div>

        {/* Profile Info */}
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="relative group cursor-pointer" onClick={handleImageClick}>
            <div className="h-28 w-28 rounded-full bg-surface-light border-4 border-primary p-1 overflow-hidden">
              <img 
                src={user?.profileImage || "https://picsum.photos/seed/user/200/200"} 
                alt="Profile" 
                className="rounded-full w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute bottom-0 right-0 h-8 w-8 bg-primary rounded-full flex items-center justify-center text-black border-4 border-background group-hover:scale-110 transition-transform">
              <Camera className="h-4 w-4" />
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept="image/*"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold">{user?.name || 'User Name'}</h2>
            <p className="text-sm text-text-muted">{user?.email}</p>
          </div>
          {user?.goal && (
            <div className="bg-primary/20 text-primary text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              {user.goal}
            </div>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4">
          <ProfileStat label="Age" value={user?.age || '--'} icon={User} />
          <ProfileStat label="Height" value={`${user?.height || '--'} cm`} icon={Ruler} />
          <ProfileStat label="Weight" value={`${user?.weight || '--'} kg`} icon={Weight} />
        </div>

        {/* Account Sections */}
        <div className="space-y-6">
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-text-muted uppercase tracking-widest ml-1">Activity</h3>
            <SettingItem icon={History} label="Workout History" onClick={() => navigate('/history')} />
            <SettingItem icon={UtensilsCrossed} label="Diet History" onClick={() => navigate('/diet-history')} />
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-bold text-text-muted uppercase tracking-widest ml-1">Account</h3>
            <SettingItem icon={Shield} label="Privacy & Security" />
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-bold text-text-muted uppercase tracking-widest ml-1">Support</h3>
            <SettingItem icon={HelpCircle} label="Help Center" />
            <SettingItem icon={LogOut} label="Log Out" color="bg-orange-500/10 text-orange-500" onClick={handleLogout} />
          </div>

          <div className="pt-4 space-y-8">
            <div className="text-center space-y-1 opacity-20">
              <p className="text-xs font-bold uppercase tracking-[0.3em]">FitBuddy</p>
              <p className="text-[8px] font-medium">Version 1.0.0 (Beta)</p>
            </div>
          </div>
        </div>

      </div>
    </MainLayout>
  );
}
