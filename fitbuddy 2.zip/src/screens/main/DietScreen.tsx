import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Calendar, Search, ChevronRight, CheckCircle2, Sparkles, Loader2, UtensilsCrossed, Flame, History, Plus, CheckSquare, Square, Check, Play } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { useApp, Meal } from '@/context/AppContext';
import { generateDietPlan } from '@/screens/onboarding/services/aiService';
import { logMealToHistory } from '@/screens/onboarding/services/historyService';
import { auth } from '@/lib/firebase';

export default function DietScreen() {
  const navigate = useNavigate();
  const { user, updateUser, isOffline } = useApp();
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGeneratePlan = async () => {
    if (!user || isGenerating) return;
    setIsGenerating(true);
    try {
      if (isOffline) {
        throw new Error("Internet connection required to generate new plan.");
      }
      const plan = await generateDietPlan(user);
      
      // HARD RESET: Reset all tracking data for the new plan
      updateUser({ 
        dietPlan: plan,
        completedMeals: [], // Reset completed meals
        dailyStats: {
          ...user.dailyStats,
          dayId: Date.now().toString(), // New unique dayId
          calories: 0, // Reset consumed calories
          protein: 0, // Reset consumed protein
          calorieTarget: plan.days[0].dailyNutritionSummary.totalCalories,
          proteinTarget: plan.days[0].dailyNutritionSummary.totalProtein,
          isDayComplete: false
        }
      });
    } catch (error: any) {
      console.error("Failed to generate diet plan:", error);
      setError(error.message || "Failed to generate diet plan");
    } finally {
      setIsGenerating(false);
    }
  };

  // Auto-generate on first visit if missing
  useEffect(() => {
    if (user && !user.dietPlan && !isGenerating) {
      handleGeneratePlan();
    }
  }, [user?.dietPlan]);

  const todayStr = new Date().toISOString().split('T')[0];
  const todayName = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  const [selectedDay, setSelectedDay] = useState<string>(todayName);

  const currentDayDiet = user?.dietPlan?.days?.find(d => d.day === selectedDay) || user?.dietPlan?.days?.[0];

  const handleLogMeal = async (meal: Meal, type: string) => {
    if (!user || !auth.currentUser || !currentDayDiet) return;
    
    const isAlreadyLogged = user.completedMeals?.some(m => m.dayId === user.dailyStats.dayId && m.mealName === meal.name);
    
    if (isAlreadyLogged) return;

    // 1. Instant UI Update (Optimistic)
    const currentCompleted = user.completedMeals || [];
    const newMeal = {
      dayId: user.dailyStats.dayId,
      date: todayStr,
      mealName: meal.name,
      calories: meal.calories,
      protein: meal.protein,
      type
    };
    
    // Update local state immediately
    updateUser({
      completedMeals: [...currentCompleted, newMeal],
      dailyStats: {
        ...user.dailyStats,
        calories: (user.dailyStats?.calories || 0) + meal.calories,
        protein: (user.dailyStats?.protein || 0) + meal.protein
      }
    });

    try {
      // 2. Background Sync
      await logMealToHistory(auth.currentUser.uid, meal.name, meal.calories, meal.protein);
    } catch (error: any) {
      console.error("Failed to log meal to history:", error);
      // We don't alert here to keep it non-intrusive as per requirements
    }
  };

  const MealCard = ({ type, meal, color }: { type: string, meal: Meal | null, color: string }) => {
    if (!meal) return null;
    const isLogged = user?.completedMeals?.some(m => m.dayId === user?.dailyStats?.dayId && m.mealName === meal.name);

    return (
      <div className="bg-surface border border-surface-light rounded-[2.5rem] p-8 relative overflow-hidden group shadow-2xl shadow-primary/5">
        <div className="flex flex-col md:flex-row gap-8 items-start relative z-10">
          <div className="flex-1 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "h-3 w-3 rounded-full shadow-lg", 
                  color === 'green' ? 'bg-green-500 shadow-green-500/50' : 
                  color === 'orange' ? 'bg-orange-500 shadow-orange-500/50' : 
                  'bg-blue-500 shadow-blue-500/50'
                )} />
                <span className="text-[10px] font-bold text-primary uppercase tracking-[0.2em]">{type}</span>
              </div>
              
              <button 
                onClick={() => handleLogMeal(meal, type)}
                disabled={isLogged}
                className={cn(
                  "h-10 w-10 rounded-xl flex items-center justify-center transition-all active:scale-90",
                  isLogged ? "bg-primary text-black" : "bg-surface-light text-text-muted hover:text-primary hover:bg-primary/10"
                )}
              >
                {isLogged ? <Check className="h-6 w-6 stroke-[3px]" /> : <Square className="h-6 w-6" />}
              </button>
            </div>
            
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h3 className="font-bold text-2xl leading-tight tracking-tight">{meal.name}</h3>
                
                <div className="flex flex-wrap items-center gap-4 mt-4">
                  <div className="bg-surface-light/50 px-3 py-1.5 rounded-xl border border-surface-light flex items-center gap-2">
                    <Flame className="h-3.5 w-3.5 text-orange-500" />
                    <span className="text-xs font-bold">{meal.calories} kcal</span>
                  </div>
                  <div className="bg-primary/10 px-3 py-1.5 rounded-xl border border-primary/20 flex items-center gap-2">
                    <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
                    <span className="text-xs font-bold text-primary">{meal.protein}g Protein</span>
                  </div>
                  {meal.quantity && (
                    <div className="bg-surface-light/50 px-3 py-1.5 rounded-xl border border-surface-light flex items-center gap-2">
                      <span className="text-[10px] font-bold text-text-muted uppercase">Qty:</span>
                      <span className="text-xs font-bold">{meal.quantity}</span>
                    </div>
                  )}
                </div>
              </div>
              
              {meal.tutorialUrl && (
                <a 
                  href={meal.tutorialUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="h-14 w-14 rounded-2xl bg-surface-light flex flex-col items-center justify-center text-primary hover:bg-primary hover:text-black transition-all shadow-lg shrink-0 ml-4 mt-1"
                >
                  <Play className="h-6 w-6 fill-current" />
                  <span className="text-[8px] font-bold uppercase mt-1">Watch</span>
                </a>
              )}
            </div>

            <div className="space-y-2 pt-2">
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Ingredients</p>
              <div className="grid grid-cols-1 gap-2">
                {meal.ingredients.map((ing: string, i: number) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-text-muted font-medium">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary/40 shrink-0" />
                    <span className="leading-tight">{ing}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const caloriesConsumed = user?.dailyStats?.calories || 0;
  const calorieGoal = user?.dailyStats?.calorieTarget || 2000;
  
  return (
    <MainLayout>
      <div className="p-6 space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="h-12 w-12 rounded-2xl bg-surface border border-surface-light flex items-center justify-center text-primary shadow-lg">
            <Calendar className="h-6 w-6" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">Diet Plan</h1>
          <button 
            onClick={() => navigate('/diet-history')}
            className="h-12 w-12 rounded-2xl bg-surface border border-surface-light flex items-center justify-center text-text-muted hover:text-white transition-colors"
          >
            <History className="h-5 w-5" />
          </button>
        </div>

        {/* Diet Type Selector */}
        <div className="bg-surface border border-surface-light p-1.5 rounded-2xl flex shadow-inner">
          {['Veg', 'Non-Veg', 'Mixed'].map((type) => (
            <button 
              key={type}
              className={cn(
                "flex-1 py-3 text-xs font-bold transition-all rounded-xl", 
                user?.diet === type ? "bg-primary text-black shadow-lg" : "text-text-muted hover:text-white"
              )}
              onClick={() => updateUser({ diet: type as any })}
            >
              {type}
            </button>
          ))}
        </div>

        {!user?.dietPlan ? (
          <div className="flex flex-col items-center justify-center py-12 text-center space-y-6">
            <div className="h-20 w-20 rounded-full bg-surface-light flex items-center justify-center text-primary">
              <Sparkles className="h-10 w-10" />
            </div>
            <div>
              <h2 className="text-xl font-bold mb-2">No Active Diet Plan</h2>
              <p className="text-sm text-text-muted max-w-xs">
                Let our AI create a personalized 7-day nutrition plan based on your {user?.goal} goal and {user?.diet} preferences.
              </p>
            </div>
            <Button 
              className="w-full h-14" 
              onClick={handleGeneratePlan}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating Plan...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Generate AI Diet Plan
                </>
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Day Selector */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                <button 
                  key={day} 
                  onClick={() => setSelectedDay(day)} 
                  className={cn(
                    "px-5 py-2.5 rounded-2xl font-bold whitespace-nowrap transition-all", 
                    selectedDay === day 
                      ? "bg-primary text-black shadow-lg shadow-primary/20" 
                      : "bg-surface-light text-text-muted hover:text-white"
                  )}
                >
                  {day.slice(0, 3)}
                </button>
              ))}
            </div>

            <MealCard type="BREAKFAST" meal={currentDayDiet?.breakfast} color="green" />
            <MealCard type="LUNCH" meal={currentDayDiet?.lunch} color="orange" />
            <MealCard type="SNACK" meal={currentDayDiet?.snack} color="blue" />
            <MealCard type="DINNER" meal={currentDayDiet?.dinner} color="blue" />

            {/* Grocery List */}
            <div className="bg-surface border border-surface-light rounded-[2.5rem] p-8 shadow-2xl shadow-primary/5">
              <h3 className="text-xl font-bold mb-6 tracking-tight">Grocery Shopping List</h3>
              <div className="space-y-6">
                {["Vegetables", "Fruits", "Grains", "Protein Sources", "Dairy", "Other Ingredients"].map((category) => {
                  const items = user.dietPlan?.groceryList?.filter(item => item.category === category);
                  if (!items || items.length === 0) return null;
                  return (
                    <div key={category} className="space-y-3">
                      <p className="text-[10px] font-bold text-primary uppercase tracking-widest">{category}</p>
                      <div className="grid grid-cols-1 gap-2">
                        {items.map((item, i) => (
                          <div key={i} className="flex items-center gap-3 bg-surface-light/20 p-3 rounded-xl border border-transparent">
                            <div className="h-5 w-5 rounded-md border border-primary/30 flex items-center justify-center shrink-0">
                              <div className="h-2 w-2 rounded-full bg-primary/20" />
                            </div>
                            <span className="text-sm font-medium text-text-muted">{item.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            <Button 
              className="w-full bg-green-500 hover:bg-green-600 text-white border-none h-16 rounded-2xl font-bold text-lg shadow-lg shadow-green-500/20"
              onClick={handleGeneratePlan}
              disabled={isGenerating}
            >
              {isGenerating ? <Loader2 className="h-5 w-5 animate-spin" /> : "Regenerate 7-Day Diet Plan"}
            </Button>
          </div>
        )}

      </div>
      <Modal isOpen={!!error} onClose={() => setError(null)} title="Error">
        <div className="text-center space-y-4">
          <p className="text-text-muted">{error}</p>
          <Button onClick={() => setError(null)} className="w-full bg-primary text-black hover:bg-primary/90">
            Close
          </Button>
        </div>
      </Modal>
    </MainLayout>
  );
}
