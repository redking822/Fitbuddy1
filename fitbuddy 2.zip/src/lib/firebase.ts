import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, setPersistence, browserLocalPersistence, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDsEWFR5jlXHM2VoVz9k3pVqWwQMxB71EQ",
  authDomain: "fitai-coach-ed032.firebaseapp.com",
  projectId: "fitai-coach-ed032",
  storageBucket: "fitai-coach-ed032.firebasestorage.app",
  messagingSenderId: "770822645192",
  appId: "1:770822645192:web:889d0c3ac4d60f1e20ccfd",
  measurementId: "G-2JGQBCGNC2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Set persistence to local
setPersistence(auth, browserLocalPersistence).catch(console.error);

const analytics = getAnalytics(app);

// Initialize Firestore with persistence
const databaseId = import.meta.env.VITE_FIRESTORE_DATABASE_ID || "(default)";
const db = initializeFirestore(app, {
  localCache: persistentLocalCache({})
}, databaseId);

const googleProvider = new GoogleAuthProvider();

export { auth, app, analytics, db, googleProvider, signInWithPopup, signInWithRedirect, getRedirectResult, setPersistence, browserLocalPersistence, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail };
