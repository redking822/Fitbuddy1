export const foodImages: Record<string, string> = {
  "oats_banana_bowl": "/assets/foods/oats_bowl.png",
  "chicken_salad": "/assets/foods/chicken_salad.png",
  "greek_yogurt_berries": "/assets/foods/greek_yogurt.png",
  "salmon_asparagus": "/assets/foods/salmon.png",
  "quinoa_bowl": "/assets/foods/quinoa.png",
  "paneer_tikka": "/assets/foods/paneer_tikka.png",
  "eggs_avocado_toast": "/assets/foods/eggs_avocado.png",
};

export const exerciseImages: Record<string, string> = {
  "pushup": "/assets/exercises/pushup.png",
  "squat": "/assets/exercises/squat.png",
  "plank": "/assets/exercises/plank.png",
  "lunges": "/assets/exercises/lunges.png",
  "burpees": "/assets/exercises/burpees.png",
  "jumping_jacks": "/assets/exercises/jumping_jacks.png",
  "mountain_climbers": "/assets/exercises/mountain_climbers.png",
};

export const getFoodImage = (name: string): string | null => {
  const key = name.toLowerCase().replace(/\s+/g, '_');
  return foodImages[key] || null;
};

export const getExerciseImage = (name: string): string | null => {
  const key = name.toLowerCase().replace(/\s+/g, '_');
  return exerciseImages[key] || null;
};
